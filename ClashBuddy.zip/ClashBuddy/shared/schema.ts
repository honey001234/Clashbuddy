import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Base User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Village Resources
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  gold: integer("gold").notNull().default(0),
  goldCapacity: integer("gold_capacity").notNull().default(0),
  goldRate: integer("gold_rate").notNull().default(0),
  elixir: integer("elixir").notNull().default(0),
  elixirCapacity: integer("elixir_capacity").notNull().default(0),
  elixirRate: integer("elixir_rate").notNull().default(0),
  darkElixir: integer("dark_elixir").notNull().default(0),
  darkElixirCapacity: integer("dark_elixir_capacity").notNull().default(0),
  darkElixirRate: integer("dark_elixir_rate").notNull().default(0),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const insertResourceSchema = createInsertSchema(resources).omit({
  id: true,
  lastUpdated: true,
});

export type InsertResource = z.infer<typeof insertResourceSchema>;
export type Resource = typeof resources.$inferSelect;

// Village Info
export const villageInfo = pgTable("village_info", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  townHallLevel: integer("town_hall_level").notNull().default(1),
  trophies: integer("trophies").notNull().default(0),
  league: text("league").default("Unranked"),
  shieldEndTime: timestamp("shield_end_time"),
  builderBaseEnabled: boolean("builder_base_enabled").default(false),
  clanWarStatus: text("clan_war_status").default("Not in war"),
});

export const insertVillageInfoSchema = createInsertSchema(villageInfo).omit({
  id: true,
});

export type InsertVillageInfo = z.infer<typeof insertVillageInfoSchema>;
export type VillageInfo = typeof villageInfo.$inferSelect;

// Builders
export const builders = pgTable("builders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  totalBuilders: integer("total_builders").notNull().default(1),
  availableBuilders: integer("available_builders").notNull().default(1),
});

export const insertBuilderSchema = createInsertSchema(builders).omit({
  id: true,
});

export type InsertBuilder = z.infer<typeof insertBuilderSchema>;
export type Builder = typeof builders.$inferSelect;

// Building Upgrades
export const buildingUpgrades = pgTable("building_upgrades", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  builderId: integer("builder_id").notNull(),
  buildingName: text("building_name").notNull(),
  currentLevel: integer("current_level").notNull(),
  targetLevel: integer("target_level").notNull(),
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time").notNull(),
  resourceType: text("resource_type").notNull(), // "gold", "elixir", "darkElixir"
  resourceCost: integer("resource_cost").notNull(),
});

export const insertBuildingUpgradeSchema = createInsertSchema(buildingUpgrades).omit({
  id: true,
  startTime: true,
});

export type InsertBuildingUpgrade = z.infer<typeof insertBuildingUpgradeSchema>;
export type BuildingUpgrade = typeof buildingUpgrades.$inferSelect;

// Research Upgrades
export const researchUpgrades = pgTable("research_upgrades", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  troopName: text("troop_name").notNull(),
  currentLevel: integer("current_level").notNull(),
  targetLevel: integer("target_level").notNull(),
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time").notNull(),
  resourceType: text("resource_type").notNull(), // "elixir", "darkElixir"
  resourceCost: integer("resource_cost").notNull(),
});

export const insertResearchUpgradeSchema = createInsertSchema(researchUpgrades).omit({
  id: true,
  startTime: true,
});

export type InsertResearchUpgrade = z.infer<typeof insertResearchUpgradeSchema>;
export type ResearchUpgrade = typeof researchUpgrades.$inferSelect;

// Notifications
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // "builder", "resource", "troops", "war", etc.
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  isRead: true,
  createdAt: true,
});

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

// Upgrade Recommendations
export const upgradeRecommendations = pgTable("upgrade_recommendations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  buildingName: text("building_name").notNull(),
  currentLevel: integer("current_level").notNull(),
  targetLevel: integer("target_level").notNull(),
  resourceType: text("resource_type").notNull(), // "gold", "elixir", "darkElixir"
  resourceCost: integer("resource_cost").notNull(),
  priority: text("priority").notNull(), // "high", "medium", "low"
  reason: text("reason").notNull(),
});

export const insertUpgradeRecommendationSchema = createInsertSchema(upgradeRecommendations).omit({
  id: true,
});

export type InsertUpgradeRecommendation = z.infer<typeof insertUpgradeRecommendationSchema>;
export type UpgradeRecommendation = typeof upgradeRecommendations.$inferSelect;

// Attack Strategies
export const attackStrategies = pgTable("attack_strategies", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  armyComposition: jsonb("army_composition").notNull(), // JSON array of troop types and counts
  spells: jsonb("spells").notNull(), // JSON array of spell types and counts
  steps: jsonb("steps").notNull(), // JSON array of attack steps
  recommendedAgainst: text("recommended_against").notNull(), // Base types this is effective against
});

export const insertAttackStrategySchema = createInsertSchema(attackStrategies).omit({
  id: true,
});

export type InsertAttackStrategy = z.infer<typeof insertAttackStrategySchema>;
export type AttackStrategy = typeof attackStrategies.$inferSelect;
