import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Header from "@/components/Header";
import NavigationTabs from "@/components/NavigationTabs";
import Footer from "@/components/Footer";
import NotificationPopup from "@/components/NotificationPopup";
import Home from "@/pages/Home";
import Builder from "@/pages/Builder";
import Attack from "@/pages/Attack";
import Troops from "@/pages/Troops";
import Analytics from "@/pages/Analytics";
import Account from "@/pages/Account";
import { useEffect } from "react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/builder" component={Builder} />
      <Route path="/attack" component={Attack} />
      <Route path="/troops" component={Troops} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/account" component={Account} />
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Set up automatic resource and timer updates every 5 minutes
  useEffect(() => {
    // Function to check for completed upgrades and update resources
    const updateGame = async () => {
      try {
        // Update resources based on time passed
        await fetch("/api/resources/update", { method: "POST" });
        
        // Check for completed upgrades
        await fetch("/api/check-completed-upgrades", { method: "POST" });
        
        // Check shield status
        await fetch("/api/refresh-shield", { method: "POST" });
        
        // Refresh data by invalidating queries
        queryClient.invalidateQueries();
      } catch (error) {
        console.error("Error updating game state:", error);
      }
    };
    
    // Run update immediately on mount
    updateGame();
    
    // Set up interval
    const intervalId = setInterval(updateGame, 5 * 60 * 1000);
    window.refreshIntervalId = intervalId;
    
    // Clean up on unmount
    return () => {
      clearInterval(intervalId);
      window.refreshIntervalId = undefined;
    };
  }, []);
  
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen flex flex-col">
        <Header />
        <NavigationTabs />
        <Router />
        <Footer />
        <NotificationPopup />
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
