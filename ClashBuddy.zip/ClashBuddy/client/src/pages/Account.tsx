import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, RefreshCw } from "lucide-react";

// Form schema for player tag
const syncFormSchema = z.object({
  playerTag: z
    .string()
    .min(1, "Player tag is required")
    .refine(
      (tag) => /^#?[0-9A-Z]+$/.test(tag),
      "Player tag must contain only letters and numbers"
    ),
});

type SyncFormValues = z.infer<typeof syncFormSchema>;

export default function Account() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);

  // Initialize form
  const form = useForm<SyncFormValues>({
    resolver: zodResolver(syncFormSchema),
    defaultValues: {
      playerTag: "",
    },
  });

  // Handle form submission
  const onSubmit = async (data: SyncFormValues) => {
    setIsSubmitting(true);
    setApiError(null);

    try {
      // Make sure tag starts with #
      let tag = data.playerTag;
      if (!tag.startsWith("#")) {
        tag = "#" + tag;
      }

      // Call the API to sync player data
      const response = await fetch("/api/coc/sync-player", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          playerTag: tag,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to sync player data");
      }

      const result = await response.json();

      // Show success message
      toast({
        title: "Account Synced",
        description: `Successfully synced with ${result.player.name} (TH${result.player.townHallLevel})`,
      });

      // Navigate back to home page
      navigate("/");
    } catch (error) {
      console.error("Error syncing account:", error);
      setApiError(
        error instanceof Error
          ? error.message
          : "Failed to sync with Clash of Clans. Please try again."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="container mx-auto p-4 max-w-4xl">
      <h1 className="text-3xl font-bold mb-6">Account Settings</h1>

      <Card>
        <CardHeader>
          <CardTitle>Link Clash of Clans Account</CardTitle>
          <CardDescription>
            Connect your actual Clash of Clans village to enable advanced features
          </CardDescription>
        </CardHeader>
        <CardContent>
          {apiError && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{apiError}</AlertDescription>
            </Alert>
          )}

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="playerTag"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Player Tag</FormLabel>
                    <FormControl>
                      <Input placeholder="#ABCDEF" {...field} />
                    </FormControl>
                    <FormDescription>
                      Enter your Clash of Clans player tag. This can be found in
                      your in-game profile.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Syncing...
                  </>
                ) : (
                  "Sync Account"
                )}
              </Button>
            </form>
          </Form>
        </CardContent>
        <CardFooter className="flex flex-col items-start text-sm text-muted-foreground">
          <p>
            Note: Your player profile will be fetched from the official Clash of
            Clans API. This allows us to automatically optimize resources and
            suggest improvements for your actual village.
          </p>
        </CardFooter>
      </Card>
    </main>
  );
}