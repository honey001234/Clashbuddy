import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Wrench, Clock, CheckCircle, AlertTriangle, RefreshCw } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

// Helper function to format time left
const formatTimeLeft = (endTimeStr: string) => {
  const endTime = new Date(endTimeStr);
  const now = new Date();
  const totalSeconds = Math.floor((endTime.getTime() - now.getTime()) / 1000);
  
  if (totalSeconds <= 0) return "Completed";
  
  const days = Math.floor(totalSeconds / (24 * 60 * 60));
  const hours = Math.floor((totalSeconds % (24 * 60 * 60)) / (60 * 60));
  const minutes = Math.floor((totalSeconds % (60 * 60)) / 60);
  
  return `${days > 0 ? days + 'd ' : ''}${hours}h ${minutes}m`;
};

const BuilderView = () => {
  // Fetch builders data
  const { data: builders, isLoading: buildersLoading } = useQuery({
    queryKey: ['/api/builders'],
  });
  
  // Fetch ongoing building upgrades
  const { data: buildingUpgrades, isLoading: upgradesLoading } = useQuery({
    queryKey: ['/api/building-upgrades'],
  });

  // Fetch resources data
  const { data: resources, isLoading: resourcesLoading } = useQuery({
    queryKey: ['/api/resources'],
  });
  
  // Fetch upgrade recommendations
  const { data: recommendations, isLoading: recommendationsLoading } = useQuery({
    queryKey: ['/api/upgrade-recommendations'],
  });
  
  const isLoading = buildersLoading || upgradesLoading || resourcesLoading || recommendationsLoading;
  
  if (isLoading) {
    return (
      <main className="flex-grow container mx-auto px-4 py-4">
        <h1 className="text-2xl font-bold mb-4">Builder Management</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          {Array(3).fill(0).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-8 w-1/2 mb-4" />
                <Skeleton className="h-12 w-full mb-2" />
                <Skeleton className="h-4 w-3/4" />
              </CardContent>
            </Card>
          ))}
        </div>
        <Card>
          <CardHeader>
            <Skeleton className="h-8 w-1/3" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Array(5).fill(0).map((_, i) => (
                <div key={i} className="border border-neutral-100 rounded-lg p-4">
                  <div className="flex items-start mb-3">
                    <Skeleton className="h-10 w-10 rounded-full mr-3" />
                    <div className="flex-1">
                      <Skeleton className="h-5 w-1/3 mb-2" />
                      <Skeleton className="h-4 w-full" />
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-4 w-1/4" />
                    <Skeleton className="h-8 w-24" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    );
  }
  
  return (
    <main className="flex-grow container mx-auto px-4 py-4">
      <h1 className="text-2xl font-bold mb-4">Builder Management</h1>
      
      {/* Resource Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {/* Gold */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-lg font-medium flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-500 h-5 w-5 mr-2">
                  <circle cx="12" cy="12" r="8" />
                  <path d="M12 6v12" />
                  <path d="M6 12h12" />
                </svg>
                Gold
              </h2>
              <span className="text-sm text-neutral-500">{Math.round((resources.gold / resources.goldCapacity) * 100)}% full</span>
            </div>
            <div className="flex items-end space-x-2 mb-1">
              <span className="text-2xl font-bold">
                {resources.gold >= 1000000 
                  ? (resources.gold / 1000000).toFixed(1) + 'M' 
                  : (resources.gold / 1000).toFixed(0) + 'K'}
              </span>
              <span className="text-neutral-500 text-sm">/ {(resources.goldCapacity / 1000000).toFixed(1)}M</span>
            </div>
            <Progress value={(resources.gold / resources.goldCapacity) * 100} className="h-2 bg-amber-100" indicatorClassName="bg-amber-500" />
          </CardContent>
        </Card>
        
        {/* Elixir */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-lg font-medium flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-500 h-5 w-5 mr-2">
                  <path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z" />
                </svg>
                Elixir
              </h2>
              <span className="text-sm text-neutral-500">{Math.round((resources.elixir / resources.elixirCapacity) * 100)}% full</span>
            </div>
            <div className="flex items-end space-x-2 mb-1">
              <span className="text-2xl font-bold">
                {resources.elixir >= 1000000 
                  ? (resources.elixir / 1000000).toFixed(1) + 'M' 
                  : (resources.elixir / 1000).toFixed(0) + 'K'}
              </span>
              <span className="text-neutral-500 text-sm">/ {(resources.elixirCapacity / 1000000).toFixed(1)}M</span>
            </div>
            <Progress value={(resources.elixir / resources.elixirCapacity) * 100} className="h-2 bg-slate-100" indicatorClassName="bg-slate-500" />
          </CardContent>
        </Card>
        
        {/* Dark Elixir */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-lg font-medium flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-purple-700 h-5 w-5 mr-2">
                  <path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z" />
                  <path d="M12 22V2" />
                </svg>
                Dark Elixir
              </h2>
              <span className="text-sm text-neutral-500">{Math.round((resources.darkElixir / resources.darkElixirCapacity) * 100)}% full</span>
            </div>
            <div className="flex items-end space-x-2 mb-1">
              <span className="text-2xl font-bold">
                {resources.darkElixir >= 1000 
                  ? (resources.darkElixir / 1000).toFixed(1) + 'K' 
                  : resources.darkElixir}
              </span>
              <span className="text-neutral-500 text-sm">/ {(resources.darkElixirCapacity / 1000).toFixed(0)}K</span>
            </div>
            <Progress value={(resources.darkElixir / resources.darkElixirCapacity) * 100} className="h-2 bg-purple-100" indicatorClassName="bg-purple-700" />
          </CardContent>
        </Card>
      </div>
      
      {/* Builder Status & Recommendations */}
      <Tabs defaultValue="active" className="mb-6">
        <TabsList>
          <TabsTrigger value="active">Active Builders ({buildingUpgrades?.length || 0})</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations ({recommendations?.length || 0})</TabsTrigger>
        </TabsList>
        
        <TabsContent value="active">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center text-lg">
                  <Wrench className="mr-2 h-5 w-5 text-primary" />
                  Builder Status
                </CardTitle>
                <Badge variant="outline">
                  <span className="font-medium text-green-600">{builders.availableBuilders}</span>
                  <span className="text-neutral-500"> / {builders.totalBuilders} Available</span>
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {buildingUpgrades && buildingUpgrades.length > 0 ? (
                  buildingUpgrades.map((upgrade: any) => (
                    <div key={upgrade.id} className="border border-neutral-100 rounded-lg p-4">
                      <div className="flex items-start mb-3">
                        <div className="w-10 h-10 bg-neutral-100 rounded-full flex items-center justify-center mr-3">
                          <Clock className="text-neutral-500 h-5 w-5" />
                        </div>
                        <div>
                          <h3 className="font-medium">{upgrade.buildingName} Upgrade</h3>
                          <p className="text-sm text-neutral-500">Level {upgrade.currentLevel} → {upgrade.targetLevel}</p>
                          <div className="mt-2 text-sm">
                            <span className="font-mono font-medium">{formatTimeLeft(upgrade.endTime)}</span> remaining
                          </div>
                        </div>
                      </div>
                      <Progress 
                        value={
                          ((new Date().getTime() - new Date(upgrade.startTime).getTime()) / 
                           (new Date(upgrade.endTime).getTime() - new Date(upgrade.startTime).getTime())) * 100
                        } 
                        className="h-1.5 mt-2 bg-neutral-100" 
                      />
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <CheckCircle className="mx-auto h-12 w-12 text-green-500 mb-2" />
                    <h3 className="text-lg font-medium">All Builders Available</h3>
                    <p className="text-neutral-500 mt-1">You have {builders.availableBuilders} builders ready for new upgrades</p>
                  </div>
                )}

                {builders.availableBuilders > 0 && (
                  <div className="pt-4">
                    <Button className="w-full">
                      Start New Upgrade
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="recommendations">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center text-lg">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-5 w-5 text-primary">
                    <path d="M12 2v8M5 5.3l3.2 3.2M2 12h8M5.3 19l3.2-3.2M12 22v-8M18.7 19l-3.2-3.2M22 12h-8M18.7 5l-3.2 3.2" />
                  </svg>
                  Upgrade Recommendations
                </CardTitle>
                <Button variant="outline" size="sm" className="h-8">
                  <RefreshCw className="mr-1 h-4 w-4" />
                  Refresh
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recommendations && recommendations.length > 0 ? (
                  recommendations.map((rec: any) => (
                    <div key={rec.id} className="border border-neutral-100 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-medium">{rec.buildingName}</h3>
                          <p className="text-sm text-neutral-500">Level {rec.currentLevel} → {rec.targetLevel}</p>
                        </div>
                        <Badge variant="outline" className={`
                          ${rec.resourceType === 'gold' ? 'bg-amber-50 text-amber-600' : 
                            rec.resourceType === 'elixir' ? 'bg-slate-50 text-slate-600' : 
                            'bg-purple-50 text-purple-600'}
                        `}>
                          {rec.resourceCost >= 1000000 
                            ? (rec.resourceCost / 1000000).toFixed(1) + 'M' 
                            : (rec.resourceCost / 1000).toFixed(0) + 'K'}
                        </Badge>
                      </div>
                      <p className="text-sm text-neutral-500 mb-3">{rec.reason}</p>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center text-sm">
                          <AlertTriangle className={`h-4 w-4 mr-1 ${
                            rec.priority === 'high' ? 'text-green-500' :
                            rec.priority === 'medium' ? 'text-amber-500' :
                            'text-neutral-400'
                          }`} />
                          <span className={
                            rec.priority === 'high' ? 'text-green-600' :
                            rec.priority === 'medium' ? 'text-amber-600' :
                            'text-neutral-600'
                          }>
                            {rec.priority.charAt(0).toUpperCase() + rec.priority.slice(1)} Priority
                          </span>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          disabled={builders.availableBuilders === 0}
                        >
                          Start Upgrade
                        </Button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mx-auto h-12 w-12 text-neutral-300 mb-2">
                      <rect width="18" height="18" x="3" y="3" rx="2" />
                      <path d="M12 8v4" />
                      <path d="M12 16h.01" />
                    </svg>
                    <h3 className="text-lg font-medium">No Recommendations</h3>
                    <p className="text-neutral-500 mt-1">There are no upgrade recommendations at this time</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Village Optimization */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-lg">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-5 w-5 text-primary">
              <path d="m2 18 8-8 4 4 6-6" />
              <path d="m22 6-6 6-4-4-8 8" />
            </svg>
            Village Optimization
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div className="border border-neutral-100 rounded-lg p-4">
              <h3 className="font-medium mb-2 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-5 w-5 text-green-500">
                  <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
                </svg>
                Defense Analysis
              </h3>
              <p className="text-sm text-neutral-500 mb-3">
                AI analysis of your base's defenses to identify weaknesses and suggest improvements.
              </p>
              <Button variant="outline" size="sm">Analyze Defense</Button>
            </div>
            
            <div className="border border-neutral-100 rounded-lg p-4">
              <h3 className="font-medium mb-2 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-5 w-5 text-amber-500">
                  <rect x="2" y="7" width="20" height="14" rx="2" ry="2" />
                  <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
                </svg>
                Resource Planning
              </h3>
              <p className="text-sm text-neutral-500 mb-3">
                Plan your resource allocation for maximum efficiency and faster progression.
              </p>
              <Button variant="outline" size="sm">Generate Plan</Button>
            </div>
          </div>
          
          <div className="border border-neutral-100 rounded-lg p-4">
            <h3 className="font-medium mb-2 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-5 w-5 text-blue-500">
                <path d="M21 12a9 9 0 1 1-6.219-8.56" />
              </svg>
              Building Layout Optimization
            </h3>
            <p className="text-sm text-neutral-500 mb-3">
              The AI can analyze your village layout and suggest the most effective placement for buildings to maximize defense and resource protection.
            </p>
            <Button className="w-full">Optimize Layout</Button>
          </div>
        </CardContent>
      </Card>
    </main>
  );
};

export default BuilderView;
