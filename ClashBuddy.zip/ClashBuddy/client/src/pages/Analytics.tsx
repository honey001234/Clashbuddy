import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell
} from "recharts";

const Analytics = () => {
  // Fetch resources data
  const { data: resources, isLoading: resourcesLoading } = useQuery({
    queryKey: ['/api/resources'],
  });
  
  // Fetch village info data
  const { data: villageInfo, isLoading: villageInfoLoading } = useQuery({
    queryKey: ['/api/village-info'],
  });
  
  const isLoading = resourcesLoading || villageInfoLoading;
  
  if (isLoading) {
    return (
      <main className="flex-grow container mx-auto px-4 py-4">
        <h1 className="text-2xl font-bold mb-4">Village Analytics</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          {Array(3).fill(0).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-8 w-1/2 mb-4" />
                <Skeleton className="h-12 w-full mb-2" />
                <Skeleton className="h-4 w-3/4" />
              </CardContent>
            </Card>
          ))}
        </div>
        <Card>
          <CardHeader>
            <Skeleton className="h-8 w-1/3" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </main>
    );
  }
  
  // Sample data for charts
  const resourceHistory = [
    { date: 'Day 1', gold: 850000, elixir: 920000, darkElixir: 22000 },
    { date: 'Day 2', gold: 920000, elixir: 980000, darkElixir: 24000 },
    { date: 'Day 3', gold: 1050000, elixir: 1100000, darkElixir: 26000 },
    { date: 'Day 4', gold: 1120000, elixir: 950000, darkElixir: 28000 },
    { date: 'Day 5', gold: 1180000, elixir: 900000, darkElixir: 29000 },
    { date: 'Day 6', gold: 1245890, elixir: 876430, darkElixir: 32450 },
  ];
  
  const COLORS = ['#1E88E5', '#4CAF50', '#FF9800', '#F44336'];
  
  const upgradePriorities = [
    { name: 'Defenses', value: 40 },
    { name: 'Resources', value: 25 },
    { name: 'Troops', value: 25 },
    { name: 'Walls', value: 10 },
  ];
  
  const attackResults = [
    { result: 'Win', count: 15 },
    { result: 'Loss', count: 5 },
    { result: 'Draw', count: 3 },
  ];
  
  return (
    <main className="flex-grow container mx-auto px-4 py-4">
      <h1 className="text-2xl font-bold mb-4">Village Analytics</h1>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <h2 className="text-sm text-neutral-500 uppercase mb-1">Current Trophies</h2>
            <div className="flex items-baseline">
              <span className="text-3xl font-bold">{villageInfo.trophies}</span>
              <span className="text-sm text-green-600 ml-2">+45 this week</span>
            </div>
            <p className="text-sm text-neutral-500 mt-2">League: {villageInfo.league}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <h2 className="text-sm text-neutral-500 uppercase mb-1">Resource Production</h2>
            <div className="flex items-baseline">
              <span className="text-3xl font-bold">{resources.goldRate + resources.elixirRate + resources.darkElixirRate}</span>
              <span className="text-sm ml-2">resources/hour</span>
            </div>
            <p className="text-sm text-neutral-500 mt-2">30% higher than average</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <h2 className="text-sm text-neutral-500 uppercase mb-1">Upgrade Efficiency</h2>
            <div className="flex items-baseline">
              <span className="text-3xl font-bold">87%</span>
              <span className="text-sm text-amber-600 ml-2">+5% since last month</span>
            </div>
            <p className="text-sm text-neutral-500 mt-2">Based on builder idle time</p>
          </CardContent>
        </Card>
      </div>
      
      {/* Analytics Tabs */}
      <Tabs defaultValue="resources" className="mb-6">
        <TabsList className="mb-4">
          <TabsTrigger value="resources">Resources</TabsTrigger>
          <TabsTrigger value="battles">Battles</TabsTrigger>
          <TabsTrigger value="progress">Progress</TabsTrigger>
        </TabsList>
        
        <TabsContent value="resources">
          <Card>
            <CardHeader>
              <CardTitle>Resource Collection Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={resourceHistory}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip formatter={(value) => new Intl.NumberFormat().format(value)} />
                    <Legend />
                    <Line type="monotone" dataKey="gold" stroke="#FFC107" activeDot={{ r: 8 }} name="Gold" />
                    <Line type="monotone" dataKey="elixir" stroke="#78909C" name="Elixir" />
                    <Line type="monotone" dataKey="darkElixir" stroke="#7B1FA2" name="Dark Elixir" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                <div className="p-4 bg-neutral-50 rounded-lg">
                  <h3 className="text-sm font-medium mb-2">Gold Collection</h3>
                  <p className="text-2xl font-bold text-amber-500">{resources.goldRate * 24 > 1000000 
                    ? `${(resources.goldRate * 24 / 1000000).toFixed(1)}M` 
                    : `${(resources.goldRate * 24 / 1000).toFixed(1)}k`} / day</p>
                  <p className="text-sm text-neutral-500 mt-1">Based on current production rate</p>
                </div>
                
                <div className="p-4 bg-neutral-50 rounded-lg">
                  <h3 className="text-sm font-medium mb-2">Elixir Collection</h3>
                  <p className="text-2xl font-bold text-slate-500">{resources.elixirRate * 24 > 1000000 
                    ? `${(resources.elixirRate * 24 / 1000000).toFixed(1)}M` 
                    : `${(resources.elixirRate * 24 / 1000).toFixed(1)}k`} / day</p>
                  <p className="text-sm text-neutral-500 mt-1">Based on current production rate</p>
                </div>
                
                <div className="p-4 bg-neutral-50 rounded-lg">
                  <h3 className="text-sm font-medium mb-2">Dark Elixir Collection</h3>
                  <p className="text-2xl font-bold text-purple-700">{resources.darkElixirRate * 24 > 1000 
                    ? `${(resources.darkElixirRate * 24 / 1000).toFixed(1)}k` 
                    : resources.darkElixirRate * 24} / day</p>
                  <p className="text-sm text-neutral-500 mt-1">Based on current production rate</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="battles">
          <Card>
            <CardHeader>
              <CardTitle>Battle Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={attackResults}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="result" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="count" name="Battles" fill="#1E88E5" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="p-6 bg-neutral-50 rounded-lg flex flex-col justify-center">
                  <h3 className="text-lg font-medium mb-4">Battle Statistics</h3>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-neutral-500">Win Rate</span>
                        <span className="text-sm font-medium">65.2%</span>
                      </div>
                      <div className="w-full bg-neutral-200 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full" style={{ width: "65.2%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-neutral-500">Average Stars</span>
                        <span className="text-sm font-medium">2.3 / 3</span>
                      </div>
                      <div className="w-full bg-neutral-200 rounded-full h-2">
                        <div className="bg-amber-500 h-2 rounded-full" style={{ width: "76.7%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-neutral-500">Average Destruction</span>
                        <span className="text-sm font-medium">73%</span>
                      </div>
                      <div className="w-full bg-neutral-200 rounded-full h-2">
                        <div className="bg-blue-500 h-2 rounded-full" style={{ width: "73%" }}></div>
                      </div>
                    </div>
                    
                    <div className="pt-2">
                      <h4 className="text-sm font-medium mb-2">Most Effective Troop Composition</h4>
                      <p className="text-sm">LaLoon (Lava Hounds + Balloons) - 78% win rate</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="progress">
          <Card>
            <CardHeader>
              <CardTitle>Village Progression</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={upgradePriorities}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {upgradePriorities.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `${value}%`} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="p-6 bg-neutral-50 rounded-lg">
                  <h3 className="text-lg font-medium mb-4">Upgrade Progress</h3>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Overall Village Completion</span>
                        <span className="text-sm font-medium">68%</span>
                      </div>
                      <div className="w-full bg-neutral-200 rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "68%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Buildings</span>
                        <span className="text-sm font-medium">82%</span>
                      </div>
                      <div className="w-full bg-neutral-200 rounded-full h-2">
                        <div className="bg-blue-500 h-2 rounded-full" style={{ width: "82%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Defenses</span>
                        <span className="text-sm font-medium">75%</span>
                      </div>
                      <div className="w-full bg-neutral-200 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full" style={{ width: "75%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Troops</span>
                        <span className="text-sm font-medium">70%</span>
                      </div>
                      <div className="w-full bg-neutral-200 rounded-full h-2">
                        <div className="bg-amber-500 h-2 rounded-full" style={{ width: "70%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Walls</span>
                        <span className="text-sm font-medium">45%</span>
                      </div>
                      <div className="w-full bg-neutral-200 rounded-full h-2">
                        <div className="bg-red-500 h-2 rounded-full" style={{ width: "45%" }}></div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <h4 className="text-sm font-medium mb-1">Estimated Time to Max TH11</h4>
                    <p className="text-lg font-bold">3 months, 12 days</p>
                    <p className="text-xs text-neutral-500 mt-1">Based on current building and research rates</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Tips & Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle>AI Optimization Suggestions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="border border-neutral-100 rounded-lg p-4">
              <h3 className="font-medium mb-2">Resource Optimization</h3>
              <ul className="text-sm space-y-2">
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500 h-5 w-5 mr-2 flex-shrink-0">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                  <span>Prioritize upgrading Gold Mines to level 13 to increase production by 15%</span>
                </li>
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500 h-5 w-5 mr-2 flex-shrink-0">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                  <span>Upgrade Dark Elixir Drills to maximize hero upgrade potential</span>
                </li>
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500 h-5 w-5 mr-2 flex-shrink-0">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                  <span>Consider upgrading storages to prevent resource overflow during shield time</span>
                </li>
              </ul>
            </div>
            
            <div className="border border-neutral-100 rounded-lg p-4">
              <h3 className="font-medium mb-2">Attack Strategy Recommendations</h3>
              <ul className="text-sm space-y-2">
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500 h-5 w-5 mr-2 flex-shrink-0">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                  <span>Your LaLoon attack success has increased 12% from last week</span>
                </li>
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500 h-5 w-5 mr-2 flex-shrink-0">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                  <span>Try Queen Walk strategy with your level 41 Archer Queen for better results against TH11</span>
                </li>
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500 h-5 w-5 mr-2 flex-shrink-0">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                  <span>Practice Miner attacks for better resource farming efficiency</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="mt-6 border border-neutral-100 rounded-lg p-4">
            <h3 className="font-medium mb-3">Long-term Village Development Plan</h3>
            <div className="flex items-center mb-3">
              <div className="relative flex items-center justify-center">
                <svg viewBox="0 0 24 24" className="h-8 w-8">
                  <circle cx="12" cy="12" r="10" className="fill-primary/20" />
                  <circle cx="12" cy="12" r="5" className="fill-primary" />
                  <text x="12" y="14" textAnchor="middle" className="text-xs font-bold fill-white">1</text>
                </svg>
                <div className="h-1 w-10 bg-primary/20 absolute left-8"></div>
              </div>
              <div className="relative flex items-center justify-center">
                <svg viewBox="0 0 24 24" className="h-8 w-8">
                  <circle cx="12" cy="12" r="10" className="fill-primary/20" />
                  <circle cx="12" cy="12" r="5" className="fill-primary/40" />
                  <text x="12" y="14" textAnchor="middle" className="text-xs font-bold fill-white">2</text>
                </svg>
                <div className="h-1 w-10 bg-primary/20 absolute left-8"></div>
              </div>
              <div className="relative flex items-center justify-center">
                <svg viewBox="0 0 24 24" className="h-8 w-8">
                  <circle cx="12" cy="12" r="10" className="fill-primary/20" />
                  <text x="12" y="14" textAnchor="middle" className="text-xs font-bold fill-neutral-500">3</text>
                </svg>
                <div className="h-1 w-10 bg-primary/20 absolute left-8"></div>
              </div>
              <div className="relative flex items-center justify-center">
                <svg viewBox="0 0 24 24" className="h-8 w-8">
                  <circle cx="12" cy="12" r="10" className="fill-primary/20" />
                  <text x="12" y="14" textAnchor="middle" className="text-xs font-bold fill-neutral-500">4</text>
                </svg>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3 bg-primary/5 rounded">
                <h4 className="font-medium text-sm mb-1">Phase 1: Offense First (Current)</h4>
                <p className="text-xs text-neutral-600">Prioritize troop upgrades and hero levels to improve attack capabilities. Focus on LaLoon and Queen Walk strategies.</p>
              </div>
              
              <div className="p-3 bg-neutral-50 rounded">
                <h4 className="font-medium text-sm mb-1">Phase 2: Core Defenses</h4>
                <p className="text-xs text-neutral-600">Upgrade key defenses: Air Defenses, Inferno Towers, X-Bows, and Wizard Towers to build a solid defensive core.</p>
              </div>
              
              <div className="p-3 bg-neutral-50 rounded">
                <h4 className="font-medium text-sm mb-1">Phase 3: Resource Buildings</h4>
                <p className="text-xs text-neutral-600">Maximize resource production to prepare for Town Hall 12 upgrade. Upgrade all collectors and storages to maximum levels.</p>
              </div>
              
              <div className="p-3 bg-neutral-50 rounded">
                <h4 className="font-medium text-sm mb-1">Phase 4: Wall and Traps</h4>
                <p className="text-xs text-neutral-600">Complete all remaining upgrades and focus on walls to complete Town Hall 11 before progressing to TH12.</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </main>
  );
};

export default Analytics;
