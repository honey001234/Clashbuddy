import GameStatusOverview from "@/components/dashboard/GameStatusOverview";
import AlertsSection from "@/components/dashboard/AlertsSection";
import TimersSection from "@/components/dashboard/TimersSection";
import BuilderStatus from "@/components/dashboard/BuilderStatus";
import UpgradeRecommendations from "@/components/dashboard/UpgradeRecommendations";
import AttackStrategy from "@/components/dashboard/AttackStrategy";

const Home = () => {
  return (
    <main className="flex-grow container mx-auto px-4 py-4">
      {/* Game Status Overview Section */}
      <GameStatusOverview />
      
      {/* Alerts & Notifications Section */}
      <AlertsSection />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Timers & Countdowns Section */}
        <TimersSection />
        
        {/* Builder Status Section */}
        <BuilderStatus />
        
        {/* Upgrade Recommendations */}
        <UpgradeRecommendations />
      </div>
      
      {/* Attack Strategy Section */}
      <AttackStrategy />
    </main>
  );
};

export default Home;
