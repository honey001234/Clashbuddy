import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

const TroopsPage = () => {
  // Fetch research upgrades
  const { data: researchUpgrades, isLoading: researchLoading } = useQuery({
    queryKey: ['/api/research-upgrades'],
  });
  
  // Fetch resources
  const { data: resources, isLoading: resourcesLoading } = useQuery({
    queryKey: ['/api/resources'],
  });
  
  const isLoading = researchLoading || resourcesLoading;
  
  if (isLoading) {
    return (
      <main className="flex-grow container mx-auto px-4 py-4">
        <h1 className="text-2xl font-bold mb-4">Troops Management</h1>
        <div className="mb-6">
          <Skeleton className="h-10 w-64 mb-4" />
          <Card>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                {Array(3).fill(0).map((_, i) => (
                  <Skeleton key={i} className="h-24 w-full" />
                ))}
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {Array(12).fill(0).map((_, i) => (
                  <Skeleton key={i} className="h-32 w-full" />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    );
  }
  
  // Helper function to format time left
  const formatTimeLeft = (endTimeStr: string) => {
    const endTime = new Date(endTimeStr);
    const now = new Date();
    const totalSeconds = Math.floor((endTime.getTime() - now.getTime()) / 1000);
    
    if (totalSeconds <= 0) return "Completed";
    
    const days = Math.floor(totalSeconds / (24 * 60 * 60));
    const hours = Math.floor((totalSeconds % (24 * 60 * 60)) / (60 * 60));
    const minutes = Math.floor((totalSeconds % (60 * 60)) / 60);
    
    return `${days > 0 ? days + 'd ' : ''}${hours}h ${minutes}m`;
  };
  
  return (
    <main className="flex-grow container mx-auto px-4 py-4">
      <h1 className="text-2xl font-bold mb-4">Troops Management</h1>
      
      <Tabs defaultValue="training" className="mb-6">
        <TabsList className="mb-4">
          <TabsTrigger value="training">Army Training</TabsTrigger>
          <TabsTrigger value="research">Laboratory Research</TabsTrigger>
          <TabsTrigger value="upgrades">Troop Levels</TabsTrigger>
        </TabsList>
        
        <TabsContent value="training">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-5 w-5 text-primary">
                  <path d="M18 4v16M7 12h11M7 20V4" />
                </svg>
                Current Army Training
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="border border-neutral-100 rounded-lg p-4">
                  <h3 className="font-medium mb-2">Army Status</h3>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-neutral-500">Capacity</span>
                    <span className="font-medium">240/240</span>
                  </div>
                  <Progress value={100} className="h-2" />
                  <div className="mt-3 flex justify-between items-center">
                    <Badge variant="outline" className="bg-green-50 text-green-600">
                      Army Ready
                    </Badge>
                    <Button variant="outline" size="sm">
                      Quick Train
                    </Button>
                  </div>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-4">
                  <h3 className="font-medium mb-2">Spell Factory</h3>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-neutral-500">Capacity</span>
                    <span className="font-medium">11/11</span>
                  </div>
                  <Progress value={100} className="h-2" />
                  <div className="mt-3 flex justify-between items-center">
                    <Badge variant="outline" className="bg-green-50 text-green-600">
                      Spells Ready
                    </Badge>
                    <Button variant="outline" size="sm">
                      Brew Spells
                    </Button>
                  </div>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-4">
                  <h3 className="font-medium mb-2">Siege Workshop</h3>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-neutral-500">Available</span>
                    <span className="font-medium">3/6</span>
                  </div>
                  <Progress value={50} className="h-2" />
                  <div className="mt-3 flex justify-between items-center">
                    <Badge variant="outline" className="bg-amber-50 text-amber-600">
                      Training
                    </Badge>
                    <Button variant="outline" size="sm">
                      Build Siege
                    </Button>
                  </div>
                </div>
              </div>
              
              <h3 className="font-medium mb-3">Current Army Composition</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                <div className="border border-neutral-100 rounded-lg p-3 text-center">
                  <div className="w-12 h-12 mx-auto mb-2 bg-slate-100 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-slate-600">
                      <path d="M5.34 17.52A10 10 0 0 1 2 12C2 6.48 6.48 2 12 2s10 4.48 10 10c0 5.52-4.48 10-10 10" />
                      <path d="M5.34 17.52A10 10 0 0 1 2 12C2 6.48 6.48 2 12 2" />
                      <path d="M17.36 14a5 5 0 0 0 1.14-2" />
                      <path d="m9 12 3-3 3 3" />
                      <path d="M12 9v8" />
                    </svg>
                  </div>
                  <h4 className="font-medium text-sm">Balloon</h4>
                  <div className="flex justify-between text-xs text-neutral-500 mt-1">
                    <span>Level 8</span>
                    <span>x28</span>
                  </div>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-3 text-center">
                  <div className="w-12 h-12 mx-auto mb-2 bg-purple-100 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-purple-700">
                      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
                    </svg>
                  </div>
                  <h4 className="font-medium text-sm">Lava Hound</h4>
                  <div className="flex justify-between text-xs text-neutral-500 mt-1">
                    <span>Level 4</span>
                    <span>x3</span>
                  </div>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-3 text-center">
                  <div className="w-12 h-12 mx-auto mb-2 bg-purple-100 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-purple-700">
                      <path d="M7 20h10" />
                      <path d="M10 20c5.5-2.5.8-6.4 3-10" />
                      <path d="M14 20c-5.5-2.5-.8-6.4-3-10" />
                      <path d="M9 2v1.5L8 7" />
                      <path d="M15 2v1.5L16 7" />
                      <path d="M12 7.5c1.5 0 2.5.5 2.5 2.5S13.5 13 12 12" />
                      <path d="M12 12c-1.5 0-2.5-1-2.5-2.1C9.5 8 10.5 7.5 12 7.5" />
                    </svg>
                  </div>
                  <h4 className="font-medium text-sm">Minion</h4>
                  <div className="flex justify-between text-xs text-neutral-500 mt-1">
                    <span>Level 7</span>
                    <span>x20</span>
                  </div>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-3 text-center">
                  <div className="w-12 h-12 mx-auto mb-2 bg-red-100 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-red-500">
                      <path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z" />
                    </svg>
                  </div>
                  <h4 className="font-medium text-sm">Rage Spell</h4>
                  <div className="flex justify-between text-xs text-neutral-500 mt-1">
                    <span>Level 5</span>
                    <span>x3</span>
                  </div>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-3 text-center">
                  <div className="w-12 h-12 mx-auto mb-2 bg-purple-100 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-purple-700">
                      <path d="M3 12a9 9 0 1 0 18 0 9 9 0 0 0-18 0" />
                      <path d="m12 17 5-5-5-5" />
                      <path d="M7 12h10" />
                    </svg>
                  </div>
                  <h4 className="font-medium text-sm">Haste Spell</h4>
                  <div className="flex justify-between text-xs text-neutral-500 mt-1">
                    <span>Level 4</span>
                    <span>x2</span>
                  </div>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-3 text-center">
                  <div className="w-12 h-12 mx-auto mb-2 bg-slate-100 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-slate-600">
                      <rect width="8" height="12" x="8" y="6" rx="1" />
                      <path d="M8 2h8v4H8z" />
                      <path d="M8 22h8v-4H8z" />
                      <path d="M4 10v4h4v-4z" />
                      <path d="M16 10v4h4v-4z" />
                    </svg>
                  </div>
                  <h4 className="font-medium text-sm">Wall Wrecker</h4>
                  <div className="flex justify-between text-xs text-neutral-500 mt-1">
                    <span>Level 3</span>
                    <span>x1</span>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-between mt-6">
                <Button variant="outline">Edit Army</Button>
                <Button>Start Attack</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="research">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-5 w-5 text-primary">
                  <path d="M10 2v8M5 5.3l3.2 3.2M2 12h8M5.3 19l3.2-3.2M12 22v-8M18.7 19l-3.2-3.2M22 12h-8M18.7 5l-3.2 3.2" />
                </svg>
                Laboratory Research
              </CardTitle>
            </CardHeader>
            <CardContent>
              {researchUpgrades && researchUpgrades.length > 0 ? (
                <div className="border border-neutral-100 rounded-lg p-4">
                  <div className="flex items-start mb-3">
                    <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mr-3">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-slate-600">
                        <path d="M19.5 14.5 16 18v-6.5" />
                        <path d="M4 21v-8" />
                        <path d="M4 9V3" />
                        <path d="M12 21v-6" />
                        <path d="M12 11V3" />
                        <path d="M20 21v-2" />
                        <path d="M20 15V3" />
                        <path d="M12 15 4 9" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-medium text-lg">{researchUpgrades[0].troopName} Research</h3>
                      <p className="text-sm text-neutral-500">
                        Upgrading from Level {researchUpgrades[0].currentLevel} to Level {researchUpgrades[0].targetLevel}
                      </p>
                      <div className="mt-2">
                        <span className="font-mono font-medium">{formatTimeLeft(researchUpgrades[0].endTime)}</span> remaining
                      </div>
                    </div>
                  </div>
                  <Progress 
                    value={
                      ((new Date().getTime() - new Date(researchUpgrades[0].startTime).getTime()) / 
                       (new Date(researchUpgrades[0].endTime).getTime() - new Date(researchUpgrades[0].startTime).getTime())) * 100
                    } 
                    className="h-2 mt-2" 
                  />
                </div>
              ) : (
                <div className="border border-neutral-100 rounded-lg p-6 text-center">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mx-auto h-12 w-12 text-neutral-300 mb-3">
                    <path d="M10 2v8M5 5.3l3.2 3.2M2 12h8M5.3 19l3.2-3.2M12 22v-8M18.7 19l-3.2-3.2M22 12h-8M18.7 5l-3.2 3.2" />
                  </svg>
                  <h3 className="text-lg font-medium mb-1">Laboratory Available</h3>
                  <p className="text-neutral-500 mb-4">Your laboratory is not researching anything right now</p>
                  <Button>Start New Research</Button>
                </div>
              )}
              
              <h3 className="font-medium mt-6 mb-3">Available Research Options</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                <div className="border border-neutral-100 rounded-lg p-3">
                  <div className="flex items-center mb-2">
                    <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center mr-2">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-slate-600">
                        <path d="M5.34 17.52A10 10 0 0 1 2 12C2 6.48 6.48 2 12 2s10 4.48 10 10c0 5.52-4.48 10-10 10" />
                        <path d="M5.34 17.52A10 10 0 0 1 2 12C2 6.48 6.48 2 12 2" />
                        <path d="M17.36 14a5 5 0 0 0 1.14-2" />
                        <path d="m9 12 3-3 3 3" />
                        <path d="M12 9v8" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">Balloon</h4>
                      <p className="text-xs text-neutral-500">Level 8 → 9</p>
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <Badge variant="outline" className="bg-slate-50 text-slate-600">
                      8.5M Elixir
                    </Badge>
                    <span className="text-neutral-500">5d 12h</span>
                  </div>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-3">
                  <div className="flex items-center mb-2">
                    <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mr-2">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-purple-700">
                      <path d="M7 20h10" />
                      <path d="M10 20c5.5-2.5.8-6.4 3-10" />
                      <path d="M14 20c-5.5-2.5-.8-6.4-3-10" />
                      <path d="M9 2v1.5L8 7" />
                      <path d="M15 2v1.5L16 7" />
                      <path d="M12 7.5c1.5 0 2.5.5 2.5 2.5S13.5 13 12 12" />
                      <path d="M12 12c-1.5 0-2.5-1-2.5-2.1C9.5 8 10.5 7.5 12 7.5" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">Minion</h4>
                      <p className="text-xs text-neutral-500">Level 7 → 8</p>
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <Badge variant="outline" className="bg-purple-50 text-purple-600">
                      160K Dark
                    </Badge>
                    <span className="text-neutral-500">7d 0h</span>
                  </div>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-3">
                  <div className="flex items-center mb-2">
                    <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mr-2">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-red-500">
                        <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">Wizard</h4>
                      <p className="text-xs text-neutral-500">Level 9 → 10</p>
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <Badge variant="outline" className="bg-slate-50 text-slate-600">
                      7.2M Elixir
                    </Badge>
                    <span className="text-neutral-500">6d 8h</span>
                  </div>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-3">
                  <div className="flex items-center mb-2">
                    <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mr-2">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-purple-700">
                        <path d="m9 9 6 6" />
                        <path d="m9 15 6-6" />
                        <circle cx="12" cy="12" r="10" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">Witch</h4>
                      <p className="text-xs text-neutral-500">Level 4 → 5</p>
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <Badge variant="outline" className="bg-purple-50 text-purple-600">
                      190K Dark
                    </Badge>
                    <span className="text-neutral-500">8d 6h</span>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end mt-6">
                <Button>View All Upgrades</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="upgrades">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-5 w-5 text-primary">
                  <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                </svg>
                Troop Levels
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                <div className="border border-neutral-100 rounded-lg p-4 text-center">
                  <div className="w-14 h-14 mx-auto mb-2 bg-slate-100 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8 text-slate-600">
                      <path d="m18 3-4 4h-3V3h7z" />
                      <path d="M11 7 9 9H6V6l5 1z" />
                      <path d="M14 22s-4-9-4-13c0-1.5.5-2 2-2s2 .5 2 2c0 4-4 13-4 13z" />
                      <path d="M11 13v4" />
                      <path d="M7 13v4" />
                    </svg>
                  </div>
                  <h4 className="font-medium">Barbarian</h4>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-neutral-500">Level</span>
                    <span className="font-medium">9/10</span>
                  </div>
                  <Progress value={90} className="h-1.5 mt-1 mb-3" />
                  <Button variant="outline" size="sm" className="w-full">Upgrade</Button>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-4 text-center">
                  <div className="w-14 h-14 mx-auto mb-2 bg-slate-100 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8 text-slate-600">
                      <path d="M5.34 17.52A10 10 0 0 1 2 12C2 6.48 6.48 2 12 2s10 4.48 10 10c0 5.52-4.48 10-10 10" />
                      <path d="M5.34 17.52A10 10 0 0 1 2 12C2 6.48 6.48 2 12 2" />
                      <path d="M17.36 14a5 5 0 0 0 1.14-2" />
                      <path d="m9 12 3-3 3 3" />
                      <path d="M12 9v8" />
                    </svg>
                  </div>
                  <h4 className="font-medium">Balloon</h4>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-neutral-500">Level</span>
                    <span className="font-medium">8/9</span>
                  </div>
                  <Progress value={89} className="h-1.5 mt-1 mb-3" />
                  <Button variant="outline" size="sm" className="w-full">Upgrade</Button>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-4 text-center">
                  <div className="w-14 h-14 mx-auto mb-2 bg-slate-100 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8 text-slate-600">
                      <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
                    </svg>
                  </div>
                  <h4 className="font-medium">Wizard</h4>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-neutral-500">Level</span>
                    <span className="font-medium">9/10</span>
                  </div>
                  <Progress value={90} className="h-1.5 mt-1 mb-3" />
                  <Button variant="outline" size="sm" className="w-full">Upgrade</Button>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-4 text-center">
                  <div className="w-14 h-14 mx-auto mb-2 bg-purple-100 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8 text-purple-700">
                      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
                    </svg>
                  </div>
                  <h4 className="font-medium">Lava Hound</h4>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-neutral-500">Level</span>
                    <span className="font-medium">4/5</span>
                  </div>
                  <Progress value={80} className="h-1.5 mt-1 mb-3" />
                  <Button variant="outline" size="sm" className="w-full">Upgrade</Button>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-4 text-center">
                  <div className="w-14 h-14 mx-auto mb-2 bg-purple-100 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8 text-purple-700">
                      <path d="M7 20h10" />
                      <path d="M10 20c5.5-2.5.8-6.4 3-10" />
                      <path d="M14 20c-5.5-2.5-.8-6.4-3-10" />
                      <path d="M9 2v1.5L8 7" />
                      <path d="M15 2v1.5L16 7" />
                      <path d="M12 7.5c1.5 0 2.5.5 2.5 2.5S13.5 13 12 12" />
                      <path d="M12 12c-1.5 0-2.5-1-2.5-2.1C9.5 8 10.5 7.5 12 7.5" />
                    </svg>
                  </div>
                  <h4 className="font-medium">Minion</h4>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-neutral-500">Level</span>
                    <span className="font-medium">7/8</span>
                  </div>
                  <Progress value={88} className="h-1.5 mt-1 mb-3" />
                  <Button variant="outline" size="sm" className="w-full">Upgrade</Button>
                </div>
                
                <div className="border border-neutral-100 rounded-lg p-4 text-center">
                  <div className="w-14 h-14 mx-auto mb-2 bg-slate-100 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8 text-slate-600">
                      <path d="M8 2h8v2h-8z" />
                      <path d="M18 8.5c0 .3-.1.64-.26.9L15.5 14H8.5l-2.24-4.6a1.98 1.98 0 0 1 .1-2L8.5 4h7l2.14 3.4c.23.36.36.8.36 1.1z" />
                      <path d="M10 14v6h4v-6" />
                      <path d="M15 6H9" />
                      <path d="M12 6v3" />
                    </svg>
                  </div>
                  <h4 className="font-medium">Valkyrie</h4>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-neutral-500">Level</span>
                    <span className="font-medium">5/6</span>
                  </div>
                  <Progress value={83} className="h-1.5 mt-1 mb-3" indicatorClassName="bg-slate-500" />
                  <div className="text-xs text-neutral-500 mb-1">Currently Upgrading</div>
                  <Progress value={35} className="h-1.5 mb-1" />
                </div>
              </div>
              
              <div className="flex justify-between mt-6">
                <Button variant="outline">Army Overview</Button>
                <Button>Optimize Upgrades</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </main>
  );
};

export default TroopsPage;
