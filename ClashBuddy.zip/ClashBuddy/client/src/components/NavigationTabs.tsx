import { useLocation, Link } from "wouter";
import { 
  LayoutDashboard, 
  Wrench, 
  Sword, 
  Crosshair, 
  BarChart3,
  UserCircle
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface NavItemProps {
  to: string;
  label: string;
  icon: React.ReactNode;
  isActive: boolean;
  hasBadge?: boolean;
}

const NavItem = ({ to, label, icon, isActive, hasBadge = false }: NavItemProps) => {
  return (
    <Link to={to}>
      <a className={`px-4 py-2 font-medium flex items-center relative whitespace-nowrap ${
        isActive 
          ? "text-primary border-b-2 border-primary" 
          : "text-neutral-300 hover:text-primary"
      }`}>
        <span className="mr-1">{icon}</span>
        {label}
        {hasBadge && (
          <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-orange-400" />
        )}
      </a>
    </Link>
  );
};

const NavigationTabs = () => {
  const [location] = useLocation();
  
  // Check if any troops are ready
  const { data: notifications } = useQuery({
    queryKey: ['/api/notifications'],
  });
  
  const hasTroopsReady = notifications && notifications.some(
    (notif: any) => notif.type === 'troops' && notif.title.includes('Ready') && !notif.isRead
  );
  
  return (
    <div className="bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex overflow-x-auto hide-scrollbar py-1">
          <NavItem 
            to="/" 
            label="Dashboard" 
            icon={<LayoutDashboard size={18} />}
            isActive={location === "/"}
          />
          <NavItem 
            to="/builder" 
            label="Builder" 
            icon={<Wrench size={18} />}
            isActive={location === "/builder"}
          />
          <NavItem 
            to="/attack" 
            label="Attack" 
            icon={<Sword size={18} />}
            isActive={location === "/attack"}
          />
          <NavItem 
            to="/troops" 
            label="Troops" 
            icon={<Crosshair size={18} />}
            isActive={location === "/troops"}
            hasBadge={hasTroopsReady}
          />
          <NavItem 
            to="/analytics" 
            label="Analytics" 
            icon={<BarChart3 size={18} />}
            isActive={location === "/analytics"}
          />
          <NavItem 
            to="/account" 
            label="Account" 
            icon={<UserCircle size={18} />}
            isActive={location === "/account"}
          />
        </div>
      </div>
    </div>
  );
};

export default NavigationTabs;
