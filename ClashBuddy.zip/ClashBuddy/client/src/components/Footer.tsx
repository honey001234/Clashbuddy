import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { RefreshCw, Settings } from "lucide-react";
import { useState } from "react";

const Footer = () => {
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // Refresh data mutation
  const refreshMutation = useMutation({
    mutationFn: async () => {
      setIsRefreshing(true);
      // Update resources
      await apiRequest('POST', '/api/resources/update');
      // Check for completed upgrades
      await apiRequest('POST', '/api/check-completed-upgrades');
      // Refresh shield info
      await apiRequest('POST', '/api/refresh-shield');
      
      // Invalidate all queries to refresh data
      queryClient.invalidateQueries();
      
      return true;
    },
    onSuccess: () => {
      setTimeout(() => {
        setIsRefreshing(false);
      }, 1000); // Show loading state for at least 1 second
    },
    onError: (error) => {
      console.error('Failed to refresh data:', error);
      setIsRefreshing(false);
    }
  });
  
  const handleRefresh = () => {
    if (!isRefreshing) {
      refreshMutation.mutate();
    }
  };
  
  // Format the current time for display
  const formatCurrentTime = () => {
    const now = new Date();
    return now.toLocaleString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };
  
  return (
    <footer className="bg-white shadow-md mt-6">
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <p className="text-sm text-neutral-500">
              Last updated: <span className="font-medium">Today, {formatCurrentTime()}</span>
            </p>
            <p className="text-xs text-neutral-400 mt-1">
              Data refreshes automatically every 5 minutes
            </p>
          </div>
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              className="text-primary mr-4 text-sm font-medium"
              onClick={handleRefresh}
              disabled={isRefreshing}
            >
              <RefreshCw className={`text-sm mr-1 h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
              {isRefreshing ? 'Refreshing...' : 'Refresh Now'}
            </Button>
            <Button variant="ghost" className="text-neutral-500 text-sm">
              <Settings className="text-sm mr-1 h-4 w-4" />
              Settings
            </Button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
