import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { LightbulbIcon, Coins, Droplet, Droplets, AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface Recommendation {
  id: number;
  buildingName: string;
  currentLevel: number;
  targetLevel: number;
  resourceType: string;
  resourceCost: number;
  priority: string;
  reason: string;
}

const PriorityBadge = ({ priority }: { priority: string }) => {
  let icon;
  let colorClass;
  
  switch (priority) {
    case 'high':
      icon = <AlertTriangle className="text-green-600 h-3 w-3 mr-1" />;
      colorClass = "text-green-600";
      break;
    case 'medium':
      icon = <AlertTriangle className="text-amber-500 h-3 w-3 mr-1" />;
      colorClass = "text-amber-500";
      break;
    case 'low':
    default:
      icon = <AlertTriangle className="text-neutral-300 h-3 w-3 mr-1" />;
      colorClass = "text-neutral-600";
  }
  
  return (
    <div className={`text-xs flex items-center ${colorClass}`}>
      {icon}
      {priority.charAt(0).toUpperCase() + priority.slice(1)} Priority
    </div>
  );
};

const ResourceBadge = ({ type, cost }: { type: string, cost: number }) => {
  let icon;
  let className;
  
  const formattedCost = cost >= 1000000 
    ? (cost / 1000000).toFixed(1) + 'M'
    : (cost / 1000).toFixed(1) + 'k';
  
  switch (type) {
    case 'gold':
      icon = <Coins className="h-3 w-3 mr-1" />;
      className = "bg-amber-50 text-amber-600";
      break;
    case 'elixir':
      icon = <Droplet className="h-3 w-3 mr-1" />;
      className = "bg-slate-50 text-slate-600";
      break;
    case 'darkElixir':
      icon = <Droplets className="h-3 w-3 mr-1" />;
      className = "bg-purple-50 text-purple-600";
      break;
    default:
      icon = <Coins className="h-3 w-3 mr-1" />;
      className = "bg-gray-50 text-gray-600";
  }
  
  return (
    <Badge variant="outline" className={`text-xs flex items-center ${className} px-2 py-0.5`}>
      {icon}
      {formattedCost}
    </Badge>
  );
};

const RecommendationCard = ({ recommendation }: { recommendation: Recommendation }) => {
  return (
    <div className="border border-neutral-100 rounded-lg p-3">
      <div className="flex justify-between mb-2">
        <h4 className="font-medium text-sm">
          {recommendation.buildingName} (Level {recommendation.currentLevel})
        </h4>
        <ResourceBadge 
          type={recommendation.resourceType} 
          cost={recommendation.resourceCost} 
        />
      </div>
      <p className="text-xs text-neutral-500 mb-2">
        {recommendation.reason}
      </p>
      <div className="flex justify-between">
        <PriorityBadge priority={recommendation.priority} />
        <Button 
          variant="link" 
          size="sm" 
          className="text-xs p-0 h-auto font-medium text-primary"
        >
          Start when ready
        </Button>
      </div>
    </div>
  );
};

const UpgradeRecommendations = () => {
  // Fetch upgrade recommendations
  const { data: recommendations, isLoading, refetch } = useQuery({
    queryKey: ['/api/upgrade-recommendations'],
  });
  
  if (isLoading) {
    return (
      <div className="lg:col-span-1">
        <h2 className="font-sans font-semibold text-lg mb-3">AI Recommendations</h2>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-4">
              <Skeleton className="h-6 w-48" />
              <Skeleton className="h-6 w-16" />
            </div>
            <div className="space-y-4">
              {Array(4).fill(0).map((_, i) => (
                <div key={i} className="border border-neutral-100 rounded-lg p-3">
                  <div className="flex justify-between mb-2">
                    <Skeleton className="h-5 w-36" />
                    <Skeleton className="h-5 w-16" />
                  </div>
                  <Skeleton className="h-4 w-full mb-2" />
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  const handleRefresh = () => {
    refetch();
  };
  
  return (
    <div className="lg:col-span-1">
      <h2 className="font-sans font-semibold text-lg mb-3">AI Recommendations</h2>
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <LightbulbIcon className="text-primary mr-2 h-5 w-5" />
              <h3 className="font-medium">Smart Upgrade Suggestions</h3>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs text-primary font-medium"
              onClick={handleRefresh}
            >
              Refresh
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1 h-4 w-4">
                <path d="M21 2v6h-6" />
                <path d="M3 12a9 9 0 0 1 15-6.7L21 8" />
                <path d="M3 22v-6h6" />
                <path d="M21 12a9 9 0 0 1-15 6.7L3 16" />
              </svg>
            </Button>
          </div>

          <div className="space-y-4">
            {recommendations && recommendations.length > 0 ? (
              recommendations.map((recommendation: Recommendation) => (
                <RecommendationCard 
                  key={recommendation.id} 
                  recommendation={recommendation} 
                />
              ))
            ) : (
              <div className="text-center py-4">
                <p className="text-neutral-500">No upgrade recommendations available</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UpgradeRecommendations;
