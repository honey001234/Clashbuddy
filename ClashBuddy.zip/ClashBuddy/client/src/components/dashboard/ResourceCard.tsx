import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Coins, 
  Droplet, 
  Clock,
  Droplets
} from "lucide-react";

interface ResourceCardProps {
  type: "gold" | "elixir" | "darkElixir";
  title: string;
  current: number;
  capacity: number;
  rate: number;
  icon: React.ReactNode;
  colorClass: string;
  bgColorClass: string;
}

const formatNumber = (num: number): string => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'k';
  }
  return num.toString();
};

const calculateHoursUntilFull = (current: number, capacity: number, rate: number): number => {
  if (current >= capacity || rate <= 0) return 0;
  return (capacity - current) / rate;
};

const formatTime = (hours: number): string => {
  if (hours <= 0) return "Full";
  
  const h = Math.floor(hours);
  const m = Math.floor((hours - h) * 60);
  
  return `${h}h ${m}m`;
};

const ResourceCard = ({
  type,
  title,
  current,
  capacity,
  rate,
  icon,
  colorClass,
  bgColorClass
}: ResourceCardProps) => {
  const percentFull = Math.round((current / capacity) * 100);
  const hoursUntilFull = calculateHoursUntilFull(current, capacity, rate);
  
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-2">
          <div className="flex items-center">
            <div className={`w-8 h-8 ${bgColorClass} rounded-full flex items-center justify-center mr-2`}>
              {icon}
            </div>
            <h3 className="font-medium">{title}</h3>
          </div>
          <Badge variant="outline" className={`text-xs ${colorClass} ${bgColorClass}`}>
            +{formatNumber(rate)}/hr
          </Badge>
        </div>
        <div className="flex justify-between mb-1">
          <span className="font-mono font-semibold">{formatNumber(current)}</span>
          <span className="text-neutral-300 font-mono text-sm">{formatNumber(capacity)}</span>
        </div>
        <div className="w-full bg-neutral-100 rounded-full overflow-hidden">
          <div 
            className={`h-2 ${colorClass}`} 
            style={{ width: `${percentFull}%` }}
          ></div>
        </div>
        <div className="mt-3 text-sm text-neutral-700">
          <span className="inline-flex items-center">
            <Clock className="h-4 w-4 mr-1" />
            Full in <span className="font-medium ml-1">{formatTime(hoursUntilFull)}</span>
          </span>
        </div>
      </CardContent>
    </Card>
  );
};

export default ResourceCard;
