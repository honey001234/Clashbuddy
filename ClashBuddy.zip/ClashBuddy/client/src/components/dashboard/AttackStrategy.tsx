import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Play } from "lucide-react";

const AttackStrategy = () => {
  // Fetch attack strategies
  const { data: strategies, isLoading } = useQuery({
    queryKey: ['/api/attack-strategies'],
  });
  
  if (isLoading) {
    return (
      <div className="mt-6">
        <h2 className="font-sans font-semibold text-lg mb-3">Attack Strategy</h2>
        <Card>
          <CardContent className="p-4">
            <div className="lg:flex">
              <div className="lg:w-2/5 mb-4 lg:mb-0 lg:mr-4">
                <Skeleton className="h-8 w-3/4 mb-3" />
                <Skeleton className="aspect-square w-full rounded-lg" />
              </div>
              <div className="lg:w-3/5">
                <Skeleton className="h-8 w-2/3 mb-3" />
                <Skeleton className="h-24 w-full mb-4" />
                <Skeleton className="h-6 w-full mb-2" />
                <div className="grid grid-cols-5 gap-2 mb-4">
                  {Array(5).fill(0).map((_, i) => (
                    <Skeleton key={i} className="w-full h-20" />
                  ))}
                </div>
                <Skeleton className="h-6 w-full mb-2" />
                <div className="space-y-2 mb-4">
                  {Array(5).fill(0).map((_, i) => (
                    <Skeleton key={i} className="w-full h-8" />
                  ))}
                </div>
                <Skeleton className="h-10 w-full" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // By default, show the first strategy
  const currentStrategy = strategies && strategies.length > 0 ? strategies[0] : null;
  
  return (
    <div className="mt-6">
      <h2 className="font-sans font-semibold text-lg mb-3">Attack Strategy</h2>
      <Card>
        <CardContent className="p-4">
          <div className="lg:flex">
            {/* Base Analysis Visualization */}
            <div className="lg:w-2/5 mb-4 lg:mb-0 lg:mr-4">
              <div className="border border-neutral-100 rounded-lg p-3">
                <h3 className="font-medium text-sm mb-2">Opponent Base Analysis</h3>
                <div className="bg-neutral-50 p-4 rounded-lg aspect-square relative">
                  {/* This is a static SVG representation of a base layout */}
                  <svg width="100%" height="100%" className="absolute inset-0">
                    <defs>
                      <marker id="arrowhead" markerWidth="10" markerHeight="7" 
                              refX="0" refY="3.5" orient="auto">
                        <polygon points="0 0, 10 3.5, 0 7" fill="#1E88E5" />
                      </marker>
                    </defs>
                    
                    {/* Grid */}
                    <g stroke="#e5e5e5" strokeWidth="0.5">
                      {Array(9).fill(0).map((_, i) => (
                        <line key={`v-${i}`} x1={(i + 1) * 25} y1="0" x2={(i + 1) * 25} y2="250" />
                      ))}
                      {Array(9).fill(0).map((_, i) => (
                        <line key={`h-${i}`} x1="0" y1={(i + 1) * 25} x2="250" y2={(i + 1) * 25} />
                      ))}
                    </g>
                    
                    {/* Town Hall */}
                    <rect x="112.5" y="112.5" width="25" height="25" fill="#FEE2E2" stroke="#EF4444" strokeWidth="2" />
                    <text x="125" y="128" fontSize="10" textAnchor="middle" fill="#EF4444">TH</text>
                    
                    {/* Air Defenses */}
                    <circle cx="75" cy="75" r="10" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="1.5" />
                    <circle cx="175" cy="75" r="10" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="1.5" />
                    <circle cx="75" cy="175" r="10" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="1.5" />
                    <circle cx="175" cy="175" r="10" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="1.5" />
                    
                    {/* Inferno Towers */}
                    <polygon points="100,125 112.5,112.5 100,100 87.5,112.5" fill="#FEE2E2" stroke="#EF4444" strokeWidth="1.5" />
                    <polygon points="150,125 162.5,112.5 150,100 137.5,112.5" fill="#FEE2E2" stroke="#EF4444" strokeWidth="1.5" />
                    
                    {/* Walls */}
                    <path d="M100,62.5 L150,62.5 L150,187.5 L100,187.5 Z" 
                          stroke="#9CA3AF" strokeWidth="3" fill="none" />
                    
                    {/* Attack Paths */}
                    <path d="M25,75 C50,50 75,45 100,62.5" 
                          stroke="#1E88E5" strokeWidth="2" strokeDasharray="5,5" fill="none" 
                          markerEnd="url(#arrowhead)" />
                    <path d="M25,175 C50,200 75,205 100,187.5" 
                          stroke="#1E88E5" strokeWidth="2" strokeDasharray="5,5" fill="none" 
                          markerEnd="url(#arrowhead)" />
                  </svg>
                </div>
                <div className="mt-3 text-xs text-neutral-500">
                  Base analysis identifies vulnerable points for optimal attack strategy.
                </div>
              </div>
            </div>

            {/* Strategy Recommendations */}
            <div className="lg:w-3/5">
              <div className="border border-neutral-100 rounded-lg p-3">
                <h3 className="font-medium text-sm mb-2">Recommended Attack Strategy</h3>
                
                <div className="space-y-3">
                  {/* Strategy Overview */}
                  <div className="bg-neutral-50 p-3 rounded">
                    <h4 className="font-medium text-sm mb-1">{currentStrategy?.name || "LaLoon Attack"}</h4>
                    <p className="text-xs text-neutral-500">
                      {currentStrategy?.description || 
                      "This base has exposed air defenses that make it vulnerable to a LaLoon attack strategy. Approach from the northeast with lava hounds tanking damage while balloons target defenses."}
                    </p>
                  </div>
                  
                  {/* Army Composition */}
                  <div>
                    <h4 className="font-medium text-xs mb-2">Recommended Army Composition:</h4>
                    <div className="grid grid-cols-5 gap-2">
                      {currentStrategy?.armyComposition?.map((troop: any, index: number) => (
                        <div key={index} className="bg-neutral-50 p-2 rounded text-center">
                          <div className={`w-8 h-8 mx-auto mb-1 ${
                            troop.name.includes("Lava") || troop.name.includes("Minion") ? 
                            "bg-purple-100" : troop.name.includes("Balloon") ? 
                            "bg-slate-100" : "bg-neutral-100"
                          } rounded-full flex items-center justify-center`}>
                            <TroopIcon name={troop.name} />
                          </div>
                          <span className="text-xs font-medium">{troop.name}</span>
                          <span className="block text-xs text-neutral-500">x{troop.count}</span>
                        </div>
                      )) || (
                        <>
                          <div className="bg-neutral-50 p-2 rounded text-center">
                            <div className="w-8 h-8 mx-auto mb-1 bg-purple-100 rounded-full flex items-center justify-center">
                              <TroopIcon name="Lava Hound" />
                            </div>
                            <span className="text-xs font-medium">Lava H.</span>
                            <span className="block text-xs text-neutral-500">x3</span>
                          </div>
                          
                          <div className="bg-neutral-50 p-2 rounded text-center">
                            <div className="w-8 h-8 mx-auto mb-1 bg-slate-100 rounded-full flex items-center justify-center">
                              <TroopIcon name="Balloon" />
                            </div>
                            <span className="text-xs font-medium">Balloon</span>
                            <span className="block text-xs text-neutral-500">x26</span>
                          </div>
                          
                          <div className="bg-neutral-50 p-2 rounded text-center">
                            <div className="w-8 h-8 mx-auto mb-1 bg-purple-100 rounded-full flex items-center justify-center">
                              <TroopIcon name="Minion" />
                            </div>
                            <span className="text-xs font-medium">Minion</span>
                            <span className="block text-xs text-neutral-500">x20</span>
                          </div>
                          
                          <div className="bg-neutral-50 p-2 rounded text-center">
                            <div className="w-8 h-8 mx-auto mb-1 bg-red-100 rounded-full flex items-center justify-center">
                              <TroopIcon name="Rage" />
                            </div>
                            <span className="text-xs font-medium">Rage</span>
                            <span className="block text-xs text-neutral-500">x3</span>
                          </div>
                          
                          <div className="bg-neutral-50 p-2 rounded text-center">
                            <div className="w-8 h-8 mx-auto mb-1 bg-purple-100 rounded-full flex items-center justify-center">
                              <TroopIcon name="Haste" />
                            </div>
                            <span className="text-xs font-medium">Haste</span>
                            <span className="block text-xs text-neutral-500">x2</span>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                  
                  {/* Attack Steps */}
                  <div>
                    <h4 className="font-medium text-xs mb-2">Attack Sequence:</h4>
                    <ol className="text-xs space-y-2 text-neutral-700">
                      {currentStrategy?.steps?.map((step: string, index: number) => (
                        <li key={index} className="flex items-start">
                          <span className="bg-primary/20 text-primary rounded-full w-5 h-5 flex items-center justify-center flex-shrink-0 mr-2">
                            {index + 1}
                          </span>
                          <span>{step}</span>
                        </li>
                      )) || (
                        <>
                          <li className="flex items-start">
                            <span className="bg-primary/20 text-primary rounded-full w-5 h-5 flex items-center justify-center flex-shrink-0 mr-2">1</span>
                            <span>Deploy Lava Hounds to target Air Defenses from the northeast side.</span>
                          </li>
                          <li className="flex items-start">
                            <span className="bg-primary/20 text-primary rounded-full w-5 h-5 flex items-center justify-center flex-shrink-0 mr-2">2</span>
                            <span>Send Balloons in a line behind Lava Hounds, focusing on defensive structures.</span>
                          </li>
                          <li className="flex items-start">
                            <span className="bg-primary/20 text-primary rounded-full w-5 h-5 flex items-center justify-center flex-shrink-0 mr-2">3</span>
                            <span>Use Rage spells over high-value targets including Inferno Towers and X-Bows.</span>
                          </li>
                          <li className="flex items-start">
                            <span className="bg-primary/20 text-primary rounded-full w-5 h-5 flex items-center justify-center flex-shrink-0 mr-2">4</span>
                            <span>Deploy Haste spells to speed up Balloons approach to defenses.</span>
                          </li>
                          <li className="flex items-start">
                            <span className="bg-primary/20 text-primary rounded-full w-5 h-5 flex items-center justify-center flex-shrink-0 mr-2">5</span>
                            <span>Once defenses are down, send in Minions for cleanup of remaining buildings.</span>
                          </li>
                        </>
                      )}
                    </ol>
                  </div>
                  
                  <div className="pt-2">
                    <Button className="w-full">
                      <Play className="mr-1 h-4 w-4" />
                      View Attack Simulation
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Helper component to show the right troop icon based on name
const TroopIcon = ({ name }: { name: string }) => {
  if (name.includes("Lava") || name === "Lava Hound") {
    return (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-purple-700 h-4 w-4">
        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
      </svg>
    );
  } else if (name.includes("Balloon")) {
    return (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-500 h-4 w-4">
        <path d="M5.34 17.52A10 10 0 0 1 2 12C2 6.48 6.48 2 12 2s10 4.48 10 10c0 5.52-4.48 10-10 10" />
        <path d="M5.34 17.52A10 10 0 0 1 2 12C2 6.48 6.48 2 12 2" />
        <path d="M17.36 14a5 5 0 0 0 1.14-2" />
        <path d="m9 12 3-3 3 3" />
        <path d="M12 9v8" />
      </svg>
    );
  } else if (name.includes("Minion")) {
    return (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-purple-700 h-4 w-4">
        <path d="M7 20h10" />
        <path d="M10 20c5.5-2.5.8-6.4 3-10" />
        <path d="M14 20c-5.5-2.5-.8-6.4-3-10" />
        <path d="M9 2v1.5L8 7" />
        <path d="M15 2v1.5L16 7" />
        <path d="M12 7.5c1.5 0 2.5.5 2.5 2.5S13.5 13 12 12" />
        <path d="M12 12c-1.5 0-2.5-1-2.5-2.1C9.5 8 10.5 7.5 12 7.5" />
      </svg>
    );
  } else if (name.includes("Rage")) {
    return (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-500 h-4 w-4">
        <path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z" />
      </svg>
    );
  } else if (name.includes("Haste")) {
    return (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-purple-700 h-4 w-4">
        <path d="M3 12a9 9 0 1 0 18 0 9 9 0 0 0-18 0" />
        <path d="m12 17 5-5-5-5" />
        <path d="M7 12h10" />
      </svg>
    );
  }
  
  // Default icon
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-500 h-4 w-4">
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="8" x2="12" y2="12" />
      <line x1="12" y1="16" x2="12.01" y2="16" />
    </svg>
  );
};

export default AttackStrategy;
