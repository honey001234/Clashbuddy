import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useState, useEffect } from "react";

// Types for the timers
interface BuildingUpgrade {
  id: number;
  buildingName: string;
  currentLevel: number;
  targetLevel: number;
  startTime: string;
  endTime: string;
  resourceType: string;
}

interface ResearchUpgrade {
  id: number;
  troopName: string;
  currentLevel: number;
  targetLevel: number;
  startTime: string;
  endTime: string;
  resourceType: string;
}

interface VillageInfo {
  shieldEndTime: string | null;
}

// Helper function to calculate time remaining
const getTimeRemaining = (endTime: string) => {
  const total = new Date(endTime).getTime() - Date.now();
  const days = Math.floor(total / (1000 * 60 * 60 * 24));
  const hours = Math.floor((total % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((total % (1000 * 60 * 60)) / (1000 * 60));
  
  return {
    total,
    days,
    hours,
    minutes,
    formatted: `${days > 0 ? days + 'd ' : ''}${hours}h ${minutes}m`
  };
};

// Helper function to format completion date
const formatCompletionDate = (endTime: string) => {
  const date = new Date(endTime);
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  const options: Intl.DateTimeFormatOptions = { 
    hour: 'numeric', 
    minute: 'numeric', 
    hour12: true 
  };
  
  let prefix = '';
  if (date.toDateString() === today.toDateString()) {
    prefix = 'Today';
  } else if (date.toDateString() === tomorrow.toDateString()) {
    prefix = 'Tomorrow';
  } else {
    prefix = date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      month: 'short', 
      day: 'numeric' 
    });
  }
  
  return `${prefix}, ${date.toLocaleTimeString('en-US', options)}`;
};

const TimerCard = ({ 
  name, 
  level, 
  endTime, 
  icon, 
  iconColor,
  badgeColor,
  timeElapsed = 0
}: { 
  name: string;
  level: number | string;
  endTime: string;
  icon: React.ReactNode;
  iconColor: string;
  badgeColor: string;
  timeElapsed?: number;
}) => {
  const [timeRemaining, setTimeRemaining] = useState(getTimeRemaining(endTime));
  
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeRemaining(getTimeRemaining(endTime));
    }, 60000); // Update every minute
    
    return () => clearInterval(timer);
  }, [endTime]);
  
  // Calculate progress percentage
  const totalDuration = new Date(endTime).getTime() - new Date(Date.now() - timeElapsed).getTime();
  const elapsed = timeElapsed + (Date.now() - Date.now());
  const progress = Math.max(0, Math.min(100, (elapsed / totalDuration) * 100));
  
  return (
    <div className="border-b border-neutral-100 pb-4 last:border-0 last:pb-0">
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center">
          <span className={`${iconColor} mr-2`}>{icon}</span>
          <h4 className="font-medium">{name}</h4>
        </div>
        <Badge variant="secondary" className={badgeColor}>
          Level {level}
        </Badge>
      </div>
      <div className="flex items-center justify-between">
        <div className="font-mono text-xl">{timeRemaining.formatted}</div>
        <div className="text-sm text-neutral-500">
          Completes on {formatCompletionDate(endTime)}
        </div>
      </div>
      <div className="w-full bg-neutral-100 rounded-full h-1.5 mt-2 overflow-hidden">
        <div 
          className={iconColor.replace('text-', 'bg-')} 
          style={{ width: `${progress}%` }}
        ></div>
      </div>
    </div>
  );
};

const TimersSection = () => {
  // Fetch all ongoing timers
  const { data: buildingUpgrades, isLoading: buildingLoading } = useQuery({
    queryKey: ['/api/building-upgrades'],
  });
  
  const { data: researchUpgrades, isLoading: researchLoading } = useQuery({
    queryKey: ['/api/research-upgrades'],
  });
  
  const { data: villageInfo, isLoading: villageInfoLoading } = useQuery({
    queryKey: ['/api/village-info'],
  });
  
  const isLoading = buildingLoading || researchLoading || villageInfoLoading;
  
  if (isLoading) {
    return (
      <div className="lg:col-span-1">
        <h2 className="font-sans font-semibold text-lg mb-3">Active Timers</h2>
        <Card>
          <CardContent className="p-4">
            <div className="space-y-4">
              {Array(4).fill(0).map((_, i) => (
                <div key={i} className="border-b border-neutral-100 pb-4 last:border-0 last:pb-0">
                  <div className="flex justify-between mb-2">
                    <Skeleton className="h-6 w-1/3" />
                    <Skeleton className="h-6 w-16" />
                  </div>
                  <div className="flex justify-between mb-2">
                    <Skeleton className="h-6 w-1/4" />
                    <Skeleton className="h-4 w-1/3" />
                  </div>
                  <Skeleton className="h-2 w-full" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // Combine and sort all timers by end time
  const allTimers = [
    ...(buildingUpgrades || []).map((upgrade: BuildingUpgrade) => ({
      type: 'building',
      name: `${upgrade.buildingName} Upgrade`,
      level: upgrade.targetLevel,
      endTime: upgrade.endTime,
      startTime: upgrade.startTime,
      resourceType: upgrade.resourceType
    })),
    ...(researchUpgrades || []).map((upgrade: ResearchUpgrade) => ({
      type: 'research',
      name: `${upgrade.troopName} Research`,
      level: upgrade.targetLevel,
      endTime: upgrade.endTime,
      startTime: upgrade.startTime,
      resourceType: upgrade.resourceType
    })),
  ];
  
  // Add shield if active
  if (villageInfo && villageInfo.shieldEndTime) {
    allTimers.push({
      type: 'shield',
      name: 'Village Shield',
      level: 'Active',
      endTime: villageInfo.shieldEndTime,
      startTime: new Date(new Date(villageInfo.shieldEndTime).getTime() - 24 * 60 * 60 * 1000).toISOString(), // Assume 24h shield
      resourceType: 'none'
    });
  }
  
  // Sort by soonest to complete
  allTimers.sort((a, b) => new Date(a.endTime).getTime() - new Date(b.endTime).getTime());
  
  return (
    <div className="lg:col-span-1">
      <h2 className="font-sans font-semibold text-lg mb-3">Active Timers</h2>
      <Card>
        <CardContent className="p-4">
          <div className="space-y-4">
            {allTimers.length > 0 ? (
              allTimers.map((timer, index) => {
                // Calculate elapsed time for progress bar
                const elapsed = Date.now() - new Date(timer.startTime).getTime();
                
                // Determine icon and colors based on timer type
                let icon, iconColor, badgeColor;
                switch(timer.type) {
                  case 'building':
                    icon = (
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
                        <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
                      </svg>
                    );
                    iconColor = 'text-blue-500';
                    badgeColor = 'bg-blue-100 text-blue-700';
                    break;
                  case 'research':
                    icon = timer.resourceType === 'elixir' ? (
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
                        <path d="M10 2v2.5" />
                        <path d="M14 2v2.5" />
                        <path d="M8.5 15.5 10 17l4.5-4.5" />
                        <path d="M19.35 10.5A9 9 0 0 0 20 8" />
                        <path d="M6.62 4.7A9 9 0 0 0 4 8c0 4.52 3.33 7.77 6.46 11.22.86.95 2.22.95 3.08 0 .63-.7 1.27-1.44 1.91-2.22" />
                      </svg>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
                        <path d="M18.9 9.5c.6-1.3.9-2.6.9-3.9 0-3.1-2.1-4.9-5-4.9S10 2.5 10 5.6c0 .7.1 1.3.2 1.9" />
                        <path d="M12.2 2c1.2 0 2.1.3 2.9.8" />
                        <path d="m20 14-2 7-2-7" />
                        <path d="M17 13v8" />
                        <path d="m14 13 1.2 5" />
                        <path d="m7 13-1.2 5" />
                        <path d="m10 13-2 7-2-7" />
                        <path d="M7 13v8" />
                      </svg>
                    );
                    iconColor = timer.resourceType === 'elixir' ? 'text-slate-500' : 'text-purple-700';
                    badgeColor = timer.resourceType === 'elixir' ? 'bg-slate-100 text-slate-700' : 'bg-purple-100 text-purple-700';
                    break;
                  case 'shield':
                    icon = (
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                      </svg>
                    );
                    iconColor = 'text-blue-500';
                    badgeColor = 'bg-blue-100 text-blue-700';
                    break;
                  default:
                    icon = (
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
                        <circle cx="12" cy="12" r="10" />
                        <polyline points="12 6 12 12 16 14" />
                      </svg>
                    );
                    iconColor = 'text-gray-500';
                    badgeColor = 'bg-gray-100 text-gray-700';
                }
                
                return (
                  <TimerCard
                    key={index}
                    name={timer.name}
                    level={timer.level}
                    endTime={timer.endTime}
                    icon={icon}
                    iconColor={iconColor}
                    badgeColor={badgeColor}
                    timeElapsed={elapsed}
                  />
                );
              })
            ) : (
              <div className="text-center py-4">
                <p className="text-neutral-500">No active timers</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TimersSection;
