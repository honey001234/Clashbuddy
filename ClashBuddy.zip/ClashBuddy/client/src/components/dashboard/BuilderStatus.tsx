import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Wrench, Clock, CheckCircle } from "lucide-react";

// Helper function to format time left
const formatTimeLeft = (endTimeStr: string) => {
  const endTime = new Date(endTimeStr);
  const now = new Date();
  const totalSeconds = Math.floor((endTime.getTime() - now.getTime()) / 1000);
  
  if (totalSeconds <= 0) return "Completed";
  
  const days = Math.floor(totalSeconds / (24 * 60 * 60));
  const hours = Math.floor((totalSeconds % (24 * 60 * 60)) / (60 * 60));
  const minutes = Math.floor((totalSeconds % (60 * 60)) / 60);
  
  return `${days > 0 ? days + 'd ' : ''}${hours}h ${minutes}m`;
};

const BuilderStatus = () => {
  // Fetch builders data
  const { data: builders, isLoading: buildersLoading } = useQuery({
    queryKey: ['/api/builders'],
  });
  
  // Fetch ongoing building upgrades
  const { data: buildingUpgrades, isLoading: upgradesLoading } = useQuery({
    queryKey: ['/api/building-upgrades'],
  });
  
  const isLoading = buildersLoading || upgradesLoading;
  
  if (isLoading) {
    return (
      <div className="lg:col-span-1">
        <h2 className="font-sans font-semibold text-lg mb-3">Builder Status</h2>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-4">
              <Skeleton className="h-6 w-24" />
              <Skeleton className="h-6 w-16" />
            </div>
            <div className="space-y-4">
              {Array(5).fill(0).map((_, i) => (
                <div key={i} className="flex items-center bg-neutral-50 rounded-lg p-3">
                  <Skeleton className="w-8 h-8 rounded-full mr-3" />
                  <div className="flex-grow">
                    <div className="flex justify-between">
                      <Skeleton className="h-4 w-20" />
                      <Skeleton className="h-4 w-16" />
                    </div>
                    <Skeleton className="h-3 w-40 mt-1" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // Map building upgrades to builders
  const builderAssignments = [];
  
  // Add available builders
  for (let i = 0; i < builders.availableBuilders; i++) {
    builderAssignments.push({
      id: i + 1,
      isAvailable: true,
      upgrade: null
    });
  }
  
  // Add builders that are working
  if (buildingUpgrades && buildingUpgrades.length > 0) {
    buildingUpgrades.forEach((upgrade: any) => {
      builderAssignments.push({
        id: upgrade.builderId,
        isAvailable: false,
        upgrade: upgrade
      });
    });
  }
  
  // Sort builders by ID
  builderAssignments.sort((a, b) => a.id - b.id);
  
  return (
    <div className="lg:col-span-1">
      <h2 className="font-sans font-semibold text-lg mb-3">Builder Status</h2>
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Wrench className="text-primary mr-2 h-5 w-5" />
              <h3 className="font-medium">Builders</h3>
            </div>
            <div className="text-sm">
              <span className="font-medium text-green-600">{builders.availableBuilders}</span> / 
              <span> {builders.totalBuilders}</span> Available
            </div>
          </div>

          <div className="space-y-4">
            {builderAssignments.map((builder) => (
              <div 
                key={builder.id}
                className={`flex items-center ${
                  builder.isAvailable ? 'bg-green-50' : 'bg-neutral-50'
                } rounded-lg p-3`}
              >
                <div className={`w-8 h-8 ${
                  builder.isAvailable ? 'bg-green-100' : 'bg-neutral-100'
                } rounded-full flex items-center justify-center mr-3`}>
                  {builder.isAvailable ? (
                    <CheckCircle className="text-green-600 h-4 w-4" />
                  ) : (
                    <Clock className="text-neutral-500 h-4 w-4" />
                  )}
                </div>
                <div className="flex-grow">
                  <div className="flex justify-between">
                    <h4 className="font-medium text-sm">Builder {builder.id}</h4>
                    <span className={`text-xs ${
                      builder.isAvailable ? 'text-green-600' : 'text-neutral-700'
                    } font-medium`}>
                      {builder.isAvailable ? 
                        'Available' : 
                        formatTimeLeft(builder.upgrade.endTime)
                      }
                    </span>
                  </div>
                  <p className="text-xs text-neutral-500 mt-1">
                    {builder.isAvailable ? 
                      'Ready for new construction' : 
                      `Upgrading ${builder.upgrade.buildingName} (Level ${builder.upgrade.targetLevel})`
                    }
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default BuilderStatus;
