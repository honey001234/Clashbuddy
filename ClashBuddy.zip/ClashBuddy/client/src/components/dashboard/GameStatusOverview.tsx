import { useQuery } from "@tanstack/react-query";
import ResourceCard from "./ResourceCard";
import { Card, CardContent } from "@/components/ui/card";
import { Coins, Droplet, Droplets, Home } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const GameStatusOverview = () => {
  // Fetch resources data
  const { data: resources, isLoading: resourcesLoading } = useQuery({
    queryKey: ['/api/resources'],
  });
  
  // Fetch village info data
  const { data: villageInfo, isLoading: villageInfoLoading } = useQuery({
    queryKey: ['/api/village-info'],
  });
  
  if (resourcesLoading || villageInfoLoading) {
    return (
      <div className="mb-6">
        <h2 className="font-sans font-semibold text-lg mb-3">Village Status</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array(4).fill(0).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <div className="flex justify-between items-center mb-4">
                  <Skeleton className="h-8 w-24" />
                  <Skeleton className="h-6 w-16" />
                </div>
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-2 w-full mb-4" />
                <Skeleton className="h-4 w-3/4" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }
  
  const formatRemainingTime = (endTimeStr: string | null) => {
    if (!endTimeStr) return "None";
    
    const endTime = new Date(endTimeStr);
    const now = new Date();
    const diff = endTime.getTime() - now.getTime();
    
    if (diff <= 0) return "Expired";
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}h ${minutes}m remaining`;
  };
  
  return (
    <div className="mb-6">
      <h2 className="font-sans font-semibold text-lg mb-3">Village Status</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Gold Resource Card */}
        <ResourceCard
          type="gold"
          title="Gold"
          current={resources.gold}
          capacity={resources.goldCapacity}
          rate={resources.goldRate}
          icon={<Coins className="text-amber-500 h-4 w-4" />}
          colorClass="bg-amber-500"
          bgColorClass="bg-amber-100"
        />
        
        {/* Elixir Resource Card */}
        <ResourceCard
          type="elixir"
          title="Elixir"
          current={resources.elixir}
          capacity={resources.elixirCapacity}
          rate={resources.elixirRate}
          icon={<Droplet className="text-slate-500 h-4 w-4" />}
          colorClass="bg-slate-500"
          bgColorClass="bg-slate-100"
        />
        
        {/* Dark Elixir Resource Card */}
        <ResourceCard
          type="darkElixir"
          title="Dark Elixir"
          current={resources.darkElixir}
          capacity={resources.darkElixirCapacity}
          rate={resources.darkElixirRate}
          icon={<Droplets className="text-purple-700 h-4 w-4" />}
          colorClass="bg-purple-700"
          bgColorClass="bg-purple-100"
        />
        
        {/* Village Info Card */}
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center mr-2">
                  <Home className="text-primary h-4 w-4" />
                </div>
                <h3 className="font-medium">Village Info</h3>
              </div>
              <span className="text-xs bg-neutral-100 text-neutral-700 px-2 py-1 rounded font-medium">
                TH{villageInfo.townHallLevel}
              </span>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-neutral-500">Shield</span>
                <span className="font-medium">
                  {formatRemainingTime(villageInfo.shieldEndTime)}
                </span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-neutral-500">Builder Base</span>
                <span className="font-medium">
                  {villageInfo.builderBaseEnabled ? "Resources ready" : "Not available"}
                </span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-neutral-500">Clan War</span>
                <span className="font-medium text-green-600">
                  {villageInfo.clanWarStatus}
                </span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-neutral-500">League</span>
                <span className="font-medium">{villageInfo.league}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default GameStatusOverview;
