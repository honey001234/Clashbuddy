import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useState } from "react";

interface Notification {
  id: number;
  title: string;
  message: string;
  type: string;
  isRead: boolean;
  createdAt: string;
}

const getNotificationIcon = (type: string) => {
  switch (type) {
    case 'troops':
      return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-500 h-5 w-5">
          <path d="M5.3 9a4 4 0 0 0 6.2-3.3c0-.9-.3-1.7-.8-2.4a1 1 0 0 0-1.2-.2 9 9 0 0 0-1.5 11" />
          <path d="M19 9h.01" />
          <path d="M13 5.7a7 7 0 0 1 5.6-1c.5.2.8.6.8 1.2 0 4-3.6 9.3-9 11.1a1 1 0 0 1-1.2-.3 9 9 0 0 1-2.9-5" />
        </svg>
      );
    case 'builder':
      return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500 h-5 w-5">
          <path d="M14 7.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z" />
          <path d="M16.5 19a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z" />
          <path d="M9.5 19a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z" />
          <path d="M12 12v-2" />
          <path d="M12 12h2" />
          <path d="M12 12h-2" />
          <path d="M12 12v2" />
        </svg>
      );
    case 'resource':
      return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-500 h-5 w-5">
          <path d="M12 22V2M2 12h20M17 7l-5-5-5 5M17 17l-5 5-5-5" />
        </svg>
      );
    case 'war':
      return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500 h-5 w-5">
          <path d="M19 7v10a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V7" />
          <path d="M10 2h4a2 2 0 0 1 2 2v3H8V4c0-1.1.9-2 2-2z" />
          <path d="M12 12v6" />
          <path d="m15 12-3 3-3-3" />
        </svg>
      );
    case 'shield':
      return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500 h-5 w-5">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
        </svg>
      );
    default:
      return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-500 h-5 w-5">
          <circle cx="12" cy="12" r="10" />
          <line x1="12" y1="8" x2="12" y2="12" />
          <line x1="12" y1="16" x2="12.01" y2="16" />
        </svg>
      );
  }
};

const formatTimeAgo = (dateString: string) => {
  const date = new Date(dateString);
  const now = new Date();
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (seconds < 60) return `${seconds}s ago`;
  
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
};

const AlertItem = ({ notification }: { notification: Notification }) => {
  return (
    <div className={`p-4 border-b border-neutral-100 flex items-center ${
      !notification.isRead ? 'bg-orange-50' : ''
    }`}>
      <div className="flex-shrink-0 w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mr-3">
        {getNotificationIcon(notification.type)}
      </div>
      <div className="flex-grow">
        <h4 className="font-medium mb-1">{notification.title}</h4>
        <p className="text-sm text-neutral-500">{notification.message}</p>
      </div>
      <div className="flex-shrink-0 ml-2 text-right">
        <span className="text-xs text-neutral-400 block mb-1">
          {formatTimeAgo(notification.createdAt)}
        </span>
      </div>
    </div>
  );
};

const AlertsSection = () => {
  const [isClearing, setIsClearing] = useState(false);
  
  // Fetch notifications
  const { data: notifications, isLoading } = useQuery({
    queryKey: ['/api/notifications'],
  });
  
  // Clear all notifications
  const clearAllMutation = useMutation({
    mutationFn: async () => {
      setIsClearing(true);
      return apiRequest('DELETE', '/api/notifications');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      setIsClearing(false);
    },
    onError: (error) => {
      console.error('Failed to clear notifications:', error);
      setIsClearing(false);
    }
  });
  
  const handleClearAll = () => {
    if (notifications && notifications.length > 0) {
      clearAllMutation.mutate();
    }
  };
  
  if (isLoading) {
    return (
      <div className="mb-6">
        <div className="flex justify-between items-center mb-3">
          <h2 className="font-sans font-semibold text-lg">Alerts & Notifications</h2>
          <Button variant="ghost" size="sm" disabled>
            <Trash2 className="mr-1 h-4 w-4" />
            Clear All
          </Button>
        </div>
        <Card>
          <CardContent className="p-0">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="p-4 border-b border-neutral-100">
                <div className="flex">
                  <Skeleton className="w-10 h-10 rounded-full mr-3" />
                  <div className="flex-1">
                    <Skeleton className="h-5 w-1/3 mb-2" />
                    <Skeleton className="h-4 w-full" />
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-3">
        <h2 className="font-sans font-semibold text-lg">Alerts & Notifications</h2>
        <Button 
          variant="ghost" 
          size="sm"
          onClick={handleClearAll}
          disabled={!notifications || notifications.length === 0 || isClearing}
        >
          <Trash2 className="mr-1 h-4 w-4" />
          Clear All
        </Button>
      </div>
      
      <Card>
        <CardContent className="p-0">
          {notifications && notifications.length > 0 ? (
            notifications.map((notification: Notification) => (
              <AlertItem key={notification.id} notification={notification} />
            ))
          ) : (
            <div className="p-8 text-center">
              <p className="text-neutral-500">No notifications</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AlertsSection;
