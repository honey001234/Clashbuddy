import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { X, Bell, Wrench, AlertTriangle, Flag } from "lucide-react";
import { useEffect, useState } from "react";

interface Notification {
  id: number;
  title: string;
  message: string;
  type: string;
  isRead: boolean;
  createdAt: string;
}

const NotificationPopup = () => {
  const { toast } = useToast();
  const [activeNotification, setActiveNotification] = useState<Notification | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  
  // Get all notifications
  const { data: notifications } = useQuery({
    queryKey: ['/api/notifications'],
  });
  
  // Whenever there are new notifications, show the latest one
  useEffect(() => {
    if (notifications && notifications.length > 0) {
      const unreadNotifications = notifications.filter(
        (notification: Notification) => !notification.isRead
      );
      
      if (unreadNotifications.length > 0 && !isVisible) {
        // Get the latest notification
        const latestNotification = unreadNotifications[0];
        setActiveNotification(latestNotification);
        setIsVisible(true);
        
        // Auto-hide after 5 seconds
        const timer = setTimeout(() => {
          handleClose();
        }, 5000);
        
        return () => clearTimeout(timer);
      }
    }
  }, [notifications]);
  
  const handleClose = () => {
    setIsVisible(false);
    setActiveNotification(null);
  };
  
  // Get the right icon for the notification type
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'troops':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-500 h-5 w-5">
            <path d="M5.3 9a4 4 0 0 0 6.2-3.3c0-.9-.3-1.7-.8-2.4a1 1 0 0 0-1.2-.2 9 9 0 0 0-1.5 11" />
            <path d="M19 9h.01" />
            <path d="M13 5.7a7 7 0 0 1 5.6-1c.5.2.8.6.8 1.2 0 4-3.6 9.3-9 11.1a1 1 0 0 1-1.2-.3 9 9 0 0 1-2.9-5" />
          </svg>
        );
      case 'builder':
        return <Wrench className="text-green-500 h-5 w-5" />;
      case 'resource':
        return <AlertTriangle className="text-amber-500 h-5 w-5" />;
      case 'war':
        return <Flag className="text-blue-500 h-5 w-5" />;
      default:
        return <Bell className="text-neutral-500 h-5 w-5" />;
    }
  };
  
  if (!isVisible || !activeNotification) {
    return null;
  }
  
  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-xs w-full sm:w-80 shadow-lg">
      <Card>
        <CardContent className="p-4">
          <div className="flex items-start">
            <div className={`flex-shrink-0 w-10 h-10 ${
              activeNotification.type === 'troops' ? 'bg-orange-100' :
              activeNotification.type === 'builder' ? 'bg-green-100' :
              activeNotification.type === 'resource' ? 'bg-amber-100' :
              activeNotification.type === 'war' ? 'bg-blue-100' :
              'bg-neutral-100'
            } rounded-full flex items-center justify-center mr-3`}>
              {getNotificationIcon(activeNotification.type)}
            </div>
            <div className="flex-grow">
              <h4 className="font-medium mb-1">{activeNotification.title}</h4>
              <p className="text-sm text-neutral-500">{activeNotification.message}</p>
            </div>
            <button 
              className="flex-shrink-0 ml-2 text-neutral-400 hover:text-neutral-600"
              onClick={handleClose}
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default NotificationPopup;
