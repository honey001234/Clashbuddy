import { useState } from "react";
import { Bell, Settings, UserCircle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";

const Header = () => {
  const [settingsOpen, setSettingsOpen] = useState(false);
  
  // Get notifications to check if there are any unread
  const { data: notifications } = useQuery({
    queryKey: ['/api/notifications'],
  });
  
  const hasNotifications = notifications && notifications.some(
    (notification: any) => !notification.isRead
  );
  
  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <div className="w-10 h-10 mr-3 bg-white p-1 rounded-lg">
            <div className="w-full h-full bg-primary rounded-md flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white w-6 h-6">
                <path d="M12 2v8M5 5.3l3.2 3.2M2 12h8M5.3 19l3.2-3.2M12 22v-8M18.7 19l-3.2-3.2M22 12h-8M18.7 5l-3.2 3.2" />
              </svg>
            </div>
          </div>
          <h1 className="font-sans font-bold text-xl">Clash AFK Assistant</h1>
        </div>
        <div className="flex items-center">
          <div className="mr-4 relative">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative text-white hover:text-white hover:bg-white/10">
                  <Bell className="h-5 w-5" />
                  {hasNotifications && (
                    <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-orange-400" />
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Notifications</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  Mark all as read
                </DropdownMenuItem>
                <DropdownMenuItem>
                  Show all notifications
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          
          <div className="relative">
            <DropdownMenu open={settingsOpen} onOpenChange={setSettingsOpen}>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="text-white hover:text-white hover:bg-white/10">
                  <Settings className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Settings</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <Link to="/account">
                  <a>
                    <DropdownMenuItem onSelect={() => setSettingsOpen(false)}>
                      <UserCircle className="mr-2 h-4 w-4" />
                      Account Settings
                    </DropdownMenuItem>
                  </a>
                </Link>
                <DropdownMenuItem>
                  Update Game Info
                </DropdownMenuItem>
                <DropdownMenuItem>
                  Notification Settings
                </DropdownMenuItem>
                <DropdownMenuItem>
                  Timer Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  About
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
