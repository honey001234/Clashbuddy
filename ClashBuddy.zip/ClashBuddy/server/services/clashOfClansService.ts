import fetch from 'node-fetch';

const API_KEY = process.env.CLASH_OF_CLANS_API_KEY;
const BASE_URL = 'https://api.clashofclans.com/v1';

// Interface for player data
export interface PlayerData {
  name: string;
  townHallLevel: number;
  trophies: number;
  bestTrophies: number;
  warStars: number;
  attackWins: number;
  defenseWins: number;
  builderHallLevel?: number;
  versusTrophies?: number;
  versusBattleWins?: number;
  role?: string;
  warPreference?: string;
  donations?: number;
  donationsReceived?: number;
  clan?: {
    tag: string;
    name: string;
    clanLevel: number;
    badgeUrls: {
      small: string;
      large: string;
      medium: string;
    };
  };
  league?: {
    id: number;
    name: string;
    iconUrls: {
      small: string;
      tiny: string;
      medium: string;
    };
  };
  legendStatistics?: {
    legendTrophies: number;
    currentSeason: {
      trophies: number;
      rank: number;
    };
  };
  troops?: any[];
  heroes?: any[];
  spells?: any[];
}

// Interface for clan data
export interface ClanData {
  tag: string;
  name: string;
  type: string;
  description: string;
  location: {
    id: number;
    name: string;
    isCountry: boolean;
    countryCode: string;
  };
  badgeUrls: {
    small: string;
    large: string;
    medium: string;
  };
  clanLevel: number;
  clanPoints: number;
  clanVersusPoints: number;
  requiredTrophies: number;
  warFrequency: string;
  warWinStreak: number;
  warWins: number;
  warTies: number;
  warLosses: number;
  isWarLogPublic: boolean;
  warLeague: {
    id: number;
    name: string;
  };
  members: number;
  memberList: any[];
}

/**
 * Fetches player data from the Clash of Clans API
 * @param playerTag The player's tag (e.g., #ABCDEF)
 * @returns Player data or null if not found
 */
export async function getPlayerByTag(playerTag: string): Promise<PlayerData | null> {
  // Make sure tag starts with #
  if (!playerTag.startsWith('#')) {
    playerTag = `#${playerTag}`;
  }

  // URL encode the # character
  const encodedTag = encodeURIComponent(playerTag);
  
  try {
    console.log(`Attempting to fetch player data for tag: ${encodedTag}`);
    console.log(`API Key available: ${API_KEY ? 'Yes' : 'No'}`);
    
    const response = await fetch(`${BASE_URL}/players/${encodedTag}`, {
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'Accept': 'application/json'
      }
    });

    if (!response.ok) {
      console.error(`Error fetching player data: ${response.status} ${response.statusText}`);
      return null;
    }

    const data = await response.json() as PlayerData;
    return data;
  } catch (error) {
    console.error('Error fetching player data:', error);
    return null;
  }
}

/**
 * Fetches clan data from the Clash of Clans API
 * @param clanTag The clan's tag (e.g., #ABCDEF)
 * @returns Clan data or null if not found
 */
export async function getClanByTag(clanTag: string): Promise<ClanData | null> {
  // Make sure tag starts with #
  if (!clanTag.startsWith('#')) {
    clanTag = `#${clanTag}`;
  }

  // URL encode the # character
  const encodedTag = encodeURIComponent(clanTag);
  
  try {
    const response = await fetch(`${BASE_URL}/clans/${encodedTag}`, {
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'Accept': 'application/json'
      }
    });

    if (!response.ok) {
      console.error(`Error fetching clan data: ${response.status} ${response.statusText}`);
      return null;
    }

    const data = await response.json() as ClanData;
    return data;
  } catch (error) {
    console.error('Error fetching clan data:', error);
    return null;
  }
}

/**
 * Fetches current war information for a clan
 * @param clanTag The clan's tag (e.g., #ABCDEF)
 * @returns War data or null if not found
 */
export async function getCurrentWar(clanTag: string): Promise<any | null> {
  // Make sure tag starts with #
  if (!clanTag.startsWith('#')) {
    clanTag = `#${clanTag}`;
  }

  // URL encode the # character
  const encodedTag = encodeURIComponent(clanTag);
  
  try {
    const response = await fetch(`${BASE_URL}/clans/${encodedTag}/currentwar`, {
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'Accept': 'application/json'
      }
    });

    if (!response.ok) {
      console.error(`Error fetching war data: ${response.status} ${response.statusText}`);
      return null;
    }

    const data = await response.json() as any;
    return data;
  } catch (error) {
    console.error('Error fetching war data:', error);
    return null;
  }
}

/**
 * Searches for clans based on various criteria
 * @param params Search parameters
 * @returns List of clans or empty array if none found
 */
export async function searchClans(params: {
  name?: string;
  warFrequency?: string;
  locationId?: number;
  minMembers?: number;
  maxMembers?: number;
  minClanPoints?: number;
  minClanLevel?: number;
  limit?: number;
}): Promise<ClanData[]> {
  // Build query string from params
  const queryParams = new URLSearchParams();
  
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined) {
      queryParams.append(key, value.toString());
    }
  }
  
  try {
    const response = await fetch(`${BASE_URL}/clans?${queryParams.toString()}`, {
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'Accept': 'application/json'
      }
    });

    if (!response.ok) {
      console.error(`Error searching clans: ${response.status} ${response.statusText}`);
      return [];
    }

    const data = await response.json() as { items: ClanData[] };
    return data.items || [];
  } catch (error) {
    console.error('Error searching clans:', error);
    return [];
  }
}