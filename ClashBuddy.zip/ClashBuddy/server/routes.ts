import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  getPlayerByTag, 
  getClanByTag, 
  getCurrentWar, 
  searchClans 
} from "./services/clashOfClansService";

export async function registerRoutes(app: Express): Promise<Server> {
  // HTTP server instance
  const httpServer = createServer(app);

  // Helper function to handle async route handlers
  const asyncHandler = (fn: Function) => (req: any, res: any, next: any) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };

  // Get current user resources
  app.get("/api/resources", asyncHandler(async (req, res) => {
    // For demo purposes, use user id 1
    const userId = 1;
    const resources = await storage.getResources(userId);
    if (!resources) {
      return res.status(404).json({ message: "Resources not found" });
    }
    res.json(resources);
  }));

  // Get village info
  app.get("/api/village-info", asyncHandler(async (req, res) => {
    // For demo purposes, use user id 1
    const userId = 1;
    const villageInfo = await storage.getVillageInfo(userId);
    if (!villageInfo) {
      return res.status(404).json({ message: "Village info not found" });
    }
    res.json(villageInfo);
  }));

  // Get builders status
  app.get("/api/builders", asyncHandler(async (req, res) => {
    // For demo purposes, use user id 1
    const userId = 1;
    const builders = await storage.getBuilders(userId);
    if (!builders) {
      return res.status(404).json({ message: "Builders info not found" });
    }
    res.json(builders);
  }));

  // Get all building upgrades
  app.get("/api/building-upgrades", asyncHandler(async (req, res) => {
    // For demo purposes, use user id 1
    const userId = 1;
    const upgrades = await storage.getBuildingUpgrades(userId);
    res.json(upgrades);
  }));

  // Get a specific building upgrade
  app.get("/api/building-upgrades/:id", asyncHandler(async (req, res) => {
    const id = parseInt(req.params.id);
    const upgrade = await storage.getBuildingUpgrade(id);
    if (!upgrade) {
      return res.status(404).json({ message: "Building upgrade not found" });
    }
    res.json(upgrade);
  }));

  // Get all research upgrades
  app.get("/api/research-upgrades", asyncHandler(async (req, res) => {
    // For demo purposes, use user id 1
    const userId = 1;
    const upgrades = await storage.getResearchUpgrades(userId);
    res.json(upgrades);
  }));

  // Get a specific research upgrade
  app.get("/api/research-upgrades/:id", asyncHandler(async (req, res) => {
    const id = parseInt(req.params.id);
    const upgrade = await storage.getResearchUpgrade(id);
    if (!upgrade) {
      return res.status(404).json({ message: "Research upgrade not found" });
    }
    res.json(upgrade);
  }));

  // Get all notifications
  app.get("/api/notifications", asyncHandler(async (req, res) => {
    // For demo purposes, use user id 1
    const userId = 1;
    const notifications = await storage.getNotifications(userId);
    res.json(notifications);
  }));

  // Mark notification as read
  app.patch("/api/notifications/:id/read", asyncHandler(async (req, res) => {
    const id = parseInt(req.params.id);
    const updatedNotification = await storage.markNotificationAsRead(id);
    res.json(updatedNotification);
  }));

  // Delete notification
  app.delete("/api/notifications/:id", asyncHandler(async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteNotification(id);
    res.status(204).end();
  }));

  // Clear all notifications
  app.delete("/api/notifications", asyncHandler(async (req, res) => {
    // For demo purposes, use user id 1
    const userId = 1;
    const notifications = await storage.getNotifications(userId);
    
    // Delete each notification
    for (const notification of notifications) {
      await storage.deleteNotification(notification.id);
    }
    
    res.status(204).end();
  }));

  // Get upgrade recommendations
  app.get("/api/upgrade-recommendations", asyncHandler(async (req, res) => {
    // For demo purposes, use user id 1
    const userId = 1;
    const recommendations = await storage.getUpgradeRecommendations(userId);
    res.json(recommendations);
  }));

  // Get attack strategies
  app.get("/api/attack-strategies", asyncHandler(async (req, res) => {
    // For demo purposes, use user id 1
    const userId = 1;
    const strategies = await storage.getAttackStrategies(userId);
    res.json(strategies);
  }));

  // Get a specific attack strategy
  app.get("/api/attack-strategies/:id", asyncHandler(async (req, res) => {
    const id = parseInt(req.params.id);
    const strategy = await storage.getAttackStrategy(id);
    if (!strategy) {
      return res.status(404).json({ message: "Attack strategy not found" });
    }
    res.json(strategy);
  }));

  // Check and update resource timers (called periodically to keep resources up to date)
  app.post("/api/resources/update", asyncHandler(async (req, res) => {
    // For demo purposes, use user id 1
    const userId = 1;
    const resources = await storage.getResources(userId);
    if (!resources) {
      return res.status(404).json({ message: "Resources not found" });
    }

    // Calculate time elapsed since last update
    const now = new Date();
    const lastUpdated = resources.lastUpdated;
    const hoursElapsed = (now.getTime() - lastUpdated.getTime()) / (1000 * 60 * 60);

    // Update resources based on production rates
    const updatedGold = Math.min(
      resources.gold + Math.floor(resources.goldRate * hoursElapsed),
      resources.goldCapacity
    );
    
    const updatedElixir = Math.min(
      resources.elixir + Math.floor(resources.elixirRate * hoursElapsed),
      resources.elixirCapacity
    );
    
    const updatedDarkElixir = Math.min(
      resources.darkElixir + Math.floor(resources.darkElixirRate * hoursElapsed),
      resources.darkElixirCapacity
    );

    // Update the resources
    const updatedResources = await storage.updateResources(userId, {
      gold: updatedGold,
      elixir: updatedElixir,
      darkElixir: updatedDarkElixir,
      lastUpdated: now
    });

    res.json(updatedResources);
  }));

  // Check for completed building upgrades
  app.post("/api/check-completed-upgrades", asyncHandler(async (req, res) => {
    // For demo purposes, use user id 1
    const userId = 1;
    
    // Get all building upgrades
    const buildingUpgrades = await storage.getBuildingUpgrades(userId);
    const now = new Date();
    
    const completedUpgrades = [];
    
    // Check for completed building upgrades
    for (const upgrade of buildingUpgrades) {
      if (upgrade.endTime <= now) {
        // This upgrade is complete
        completedUpgrades.push(upgrade);
        
        // Free up the builder
        const builders = await storage.getBuilders(userId);
        if (builders) {
          await storage.updateBuilders(userId, {
            availableBuilders: builders.availableBuilders + 1
          });
        }
        
        // Create a notification
        await storage.createNotification({
          userId,
          title: `${upgrade.buildingName} Upgraded`,
          message: `Your ${upgrade.buildingName} has been upgraded to level ${upgrade.targetLevel}.`,
          type: "builder"
        });
        
        // Remove the upgrade from the list
        await storage.deleteBuildingUpgrade(upgrade.id);
      }
    }
    
    // Check for completed research upgrades
    const researchUpgrades = await storage.getResearchUpgrades(userId);
    const completedResearch = [];
    
    for (const upgrade of researchUpgrades) {
      if (upgrade.endTime <= now) {
        // This research is complete
        completedResearch.push(upgrade);
        
        // Create a notification
        await storage.createNotification({
          userId,
          title: `${upgrade.troopName} Research Complete`,
          message: `Your ${upgrade.troopName} has been upgraded to level ${upgrade.targetLevel}.`,
          type: "research"
        });
        
        // Remove the upgrade from the list
        await storage.deleteResearchUpgrade(upgrade.id);
      }
    }
    
    res.json({
      completedBuildings: completedUpgrades,
      completedResearch: completedResearch
    });
  }));

  // Start a new building upgrade
  app.post("/api/building-upgrades", asyncHandler(async (req, res) => {
    // For demo purposes, use user id 1
    const userId = 1;
    
    // Validate request body
    const schema = z.object({
      builderId: z.number(),
      buildingName: z.string(),
      currentLevel: z.number(),
      targetLevel: z.number(),
      endTime: z.string().transform(val => new Date(val)),
      resourceType: z.string(),
      resourceCost: z.number()
    });
    
    const validatedData = schema.parse(req.body);
    
    // Check if builder is available
    const builders = await storage.getBuilders(userId);
    if (!builders || builders.availableBuilders <= 0) {
      return res.status(400).json({ message: "No builders available" });
    }
    
    // Check if enough resources
    const resources = await storage.getResources(userId);
    if (!resources) {
      return res.status(404).json({ message: "Resources not found" });
    }
    
    const resourceType = validatedData.resourceType;
    const cost = validatedData.resourceCost;
    
    let hasEnoughResources = false;
    
    if (resourceType === "gold" && resources.gold >= cost) {
      hasEnoughResources = true;
      await storage.updateResources(userId, { gold: resources.gold - cost });
    } else if (resourceType === "elixir" && resources.elixir >= cost) {
      hasEnoughResources = true;
      await storage.updateResources(userId, { elixir: resources.elixir - cost });
    } else if (resourceType === "darkElixir" && resources.darkElixir >= cost) {
      hasEnoughResources = true;
      await storage.updateResources(userId, { darkElixir: resources.darkElixir - cost });
    }
    
    if (!hasEnoughResources) {
      return res.status(400).json({ message: "Not enough resources" });
    }
    
    // Update builder count
    await storage.updateBuilders(userId, {
      availableBuilders: builders.availableBuilders - 1
    });
    
    // Create the building upgrade
    const upgrade = await storage.createBuildingUpgrade({
      userId,
      builderId: validatedData.builderId,
      buildingName: validatedData.buildingName,
      currentLevel: validatedData.currentLevel,
      targetLevel: validatedData.targetLevel,
      endTime: validatedData.endTime,
      resourceType: validatedData.resourceType,
      resourceCost: validatedData.resourceCost
    });
    
    res.status(201).json(upgrade);
  }));

  // Start a new research upgrade
  app.post("/api/research-upgrades", asyncHandler(async (req, res) => {
    // For demo purposes, use user id 1
    const userId = 1;
    
    // Validate request body
    const schema = z.object({
      troopName: z.string(),
      currentLevel: z.number(),
      targetLevel: z.number(),
      endTime: z.string().transform(val => new Date(val)),
      resourceType: z.string(),
      resourceCost: z.number()
    });
    
    const validatedData = schema.parse(req.body);
    
    // Check if laboratory is available (not currently researching anything)
    const currentResearch = await storage.getResearchUpgrades(userId);
    if (currentResearch.length > 0) {
      return res.status(400).json({ message: "Laboratory is already researching" });
    }
    
    // Check if enough resources
    const resources = await storage.getResources(userId);
    if (!resources) {
      return res.status(404).json({ message: "Resources not found" });
    }
    
    const resourceType = validatedData.resourceType;
    const cost = validatedData.resourceCost;
    
    let hasEnoughResources = false;
    
    if (resourceType === "elixir" && resources.elixir >= cost) {
      hasEnoughResources = true;
      await storage.updateResources(userId, { elixir: resources.elixir - cost });
    } else if (resourceType === "darkElixir" && resources.darkElixir >= cost) {
      hasEnoughResources = true;
      await storage.updateResources(userId, { darkElixir: resources.darkElixir - cost });
    }
    
    if (!hasEnoughResources) {
      return res.status(400).json({ message: "Not enough resources" });
    }
    
    // Create the research upgrade
    const upgrade = await storage.createResearchUpgrade({
      userId,
      troopName: validatedData.troopName,
      currentLevel: validatedData.currentLevel,
      targetLevel: validatedData.targetLevel,
      endTime: validatedData.endTime,
      resourceType: validatedData.resourceType,
      resourceCost: validatedData.resourceCost
    });
    
    res.status(201).json(upgrade);
  }));

  // Refresh village shield info
  app.post("/api/refresh-shield", asyncHandler(async (req, res) => {
    // For demo purposes, use user id 1
    const userId = 1;
    
    const villageInfo = await storage.getVillageInfo(userId);
    if (!villageInfo) {
      return res.status(404).json({ message: "Village info not found" });
    }
    
    // Check if shield has expired
    const now = new Date();
    if (villageInfo.shieldEndTime && villageInfo.shieldEndTime <= now) {
      // Shield has expired, update village info
      const updatedVillageInfo = await storage.updateVillageInfo(userId, {
        shieldEndTime: null
      });
      
      // Create notification
      await storage.createNotification({
        userId,
        title: "Shield Expired",
        message: "Your village shield has expired. Your village is now vulnerable to attacks.",
        type: "shield"
      });
      
      return res.json(updatedVillageInfo);
    }
    
    res.json(villageInfo);
  }));

  // CLASH OF CLANS API ROUTES

  // Get player data by tag
  app.get("/api/coc/player/:tag", asyncHandler(async (req, res) => {
    const tag = req.params.tag;
    const playerData = await getPlayerByTag(tag);
    
    if (!playerData) {
      return res.status(404).json({ message: "Player not found or API error" });
    }
    
    res.json(playerData);
  }));

  // Get clan data by tag
  app.get("/api/coc/clan/:tag", asyncHandler(async (req, res) => {
    const tag = req.params.tag;
    const clanData = await getClanByTag(tag);
    
    if (!clanData) {
      return res.status(404).json({ message: "Clan not found or API error" });
    }
    
    res.json(clanData);
  }));

  // Get current war data for a clan
  app.get("/api/coc/clan/:tag/war", asyncHandler(async (req, res) => {
    const tag = req.params.tag;
    const warData = await getCurrentWar(tag);
    
    if (!warData) {
      return res.status(404).json({ message: "War data not found or API error" });
    }
    
    res.json(warData);
  }));

  // Search for clans with various criteria
  app.get("/api/coc/clans/search", asyncHandler(async (req, res) => {
    const searchParams: {
      name?: string;
      warFrequency?: string;
      locationId?: number;
      minMembers?: number;
      maxMembers?: number;
      minClanPoints?: number;
      minClanLevel?: number;
      limit?: number;
    } = {};
    
    // Parse query parameters
    if (req.query.name) searchParams.name = req.query.name as string;
    if (req.query.warFrequency) searchParams.warFrequency = req.query.warFrequency as string;
    if (req.query.locationId) searchParams.locationId = parseInt(req.query.locationId as string);
    if (req.query.minMembers) searchParams.minMembers = parseInt(req.query.minMembers as string);
    if (req.query.maxMembers) searchParams.maxMembers = parseInt(req.query.maxMembers as string);
    if (req.query.minClanPoints) searchParams.minClanPoints = parseInt(req.query.minClanPoints as string);
    if (req.query.minClanLevel) searchParams.minClanLevel = parseInt(req.query.minClanLevel as string);
    if (req.query.limit) searchParams.limit = parseInt(req.query.limit as string);
    
    const clans = await searchClans(searchParams);
    res.json(clans);
  }));

  // Sync player data from Clash of Clans to local database
  app.post("/api/coc/sync-player", asyncHandler(async (req, res) => {
    // Validate request body
    const schema = z.object({
      playerTag: z.string(),
      userId: z.number().optional()
    });
    
    const validatedData = schema.parse(req.body);
    
    // For demo purposes, use user id 1 if not provided
    const userId = validatedData.userId || 1;
    
    // Get player data from Clash of Clans API
    const playerData = await getPlayerByTag(validatedData.playerTag);
    
    if (!playerData) {
      return res.status(404).json({ message: "Player not found or API error" });
    }
    
    // Update village info with data from the API
    const villageInfo = await storage.getVillageInfo(userId);
    if (!villageInfo) {
      return res.status(404).json({ message: "Village info not found" });
    }
    
    // Update the village info with player data
    const updatedVillageInfo = await storage.updateVillageInfo(userId, {
      townHallLevel: playerData.townHallLevel,
      trophies: playerData.trophies,
      league: playerData.league?.name || null,
      builderBaseEnabled: playerData.builderHallLevel ? true : null
    });
    
    // Create notification for successful sync
    await storage.createNotification({
      userId,
      title: "Account Synced",
      message: `Successfully synced data from ${playerData.name} (TH${playerData.townHallLevel}).`,
      type: "system"
    });
    
    res.json({
      message: "Player data synced successfully",
      player: playerData,
      villageInfo: updatedVillageInfo
    });
  }));

  return httpServer;
}
