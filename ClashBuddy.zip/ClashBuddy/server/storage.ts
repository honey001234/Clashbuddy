import { 
  users, type User, type InsertUser, 
  resources, type Resource, type InsertResource,
  villageInfo, type VillageInfo, type InsertVillageInfo,
  builders, type Builder, type InsertBuilder,
  buildingUpgrades, type BuildingUpgrade, type InsertBuildingUpgrade,
  researchUpgrades, type ResearchUpgrade, type InsertResearchUpgrade,
  notifications, type Notification, type InsertNotification,
  upgradeRecommendations, type UpgradeRecommendation, type InsertUpgradeRecommendation,
  attackStrategies, type AttackStrategy, type InsertAttackStrategy
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Resource methods
  getResources(userId: number): Promise<Resource | undefined>;
  updateResources(userId: number, resources: Partial<Resource>): Promise<Resource>;
  createResources(resources: InsertResource): Promise<Resource>;
  
  // Village info methods
  getVillageInfo(userId: number): Promise<VillageInfo | undefined>;
  updateVillageInfo(userId: number, info: Partial<VillageInfo>): Promise<VillageInfo>;
  createVillageInfo(info: InsertVillageInfo): Promise<VillageInfo>;
  
  // Builder methods
  getBuilders(userId: number): Promise<Builder | undefined>;
  updateBuilders(userId: number, builderData: Partial<Builder>): Promise<Builder>;
  createBuilders(builderData: InsertBuilder): Promise<Builder>;
  
  // Building upgrade methods
  getBuildingUpgrades(userId: number): Promise<BuildingUpgrade[]>;
  getBuildingUpgrade(id: number): Promise<BuildingUpgrade | undefined>;
  createBuildingUpgrade(upgrade: InsertBuildingUpgrade): Promise<BuildingUpgrade>;
  updateBuildingUpgrade(id: number, upgrade: Partial<BuildingUpgrade>): Promise<BuildingUpgrade>;
  deleteBuildingUpgrade(id: number): Promise<void>;
  
  // Research upgrade methods
  getResearchUpgrades(userId: number): Promise<ResearchUpgrade[]>;
  getResearchUpgrade(id: number): Promise<ResearchUpgrade | undefined>;
  createResearchUpgrade(upgrade: InsertResearchUpgrade): Promise<ResearchUpgrade>;
  updateResearchUpgrade(id: number, upgrade: Partial<ResearchUpgrade>): Promise<ResearchUpgrade>;
  deleteResearchUpgrade(id: number): Promise<void>;
  
  // Notification methods
  getNotifications(userId: number): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<Notification>;
  deleteNotification(id: number): Promise<void>;
  
  // Upgrade recommendation methods
  getUpgradeRecommendations(userId: number): Promise<UpgradeRecommendation[]>;
  createUpgradeRecommendation(recommendation: InsertUpgradeRecommendation): Promise<UpgradeRecommendation>;
  deleteUpgradeRecommendation(id: number): Promise<void>;
  
  // Attack strategy methods
  getAttackStrategies(userId: number): Promise<AttackStrategy[]>;
  getAttackStrategy(id: number): Promise<AttackStrategy | undefined>;
  createAttackStrategy(strategy: InsertAttackStrategy): Promise<AttackStrategy>;
  updateAttackStrategy(id: number, strategy: Partial<AttackStrategy>): Promise<AttackStrategy>;
  deleteAttackStrategy(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private resources: Map<number, Resource>;
  private villageInfos: Map<number, VillageInfo>;
  private buildersList: Map<number, Builder>;
  private buildingUpgradesList: Map<number, BuildingUpgrade>;
  private researchUpgradesList: Map<number, ResearchUpgrade>;
  private notificationsList: Map<number, Notification>;
  private upgradeRecommendationsList: Map<number, UpgradeRecommendation>;
  private attackStrategiesList: Map<number, AttackStrategy>;
  
  private userIdCounter: number;
  private resourceIdCounter: number;
  private villageInfoIdCounter: number;
  private builderIdCounter: number;
  private buildingUpgradeIdCounter: number;
  private researchUpgradeIdCounter: number;
  private notificationIdCounter: number;
  private upgradeRecommendationIdCounter: number;
  private attackStrategyIdCounter: number;

  constructor() {
    this.users = new Map();
    this.resources = new Map();
    this.villageInfos = new Map();
    this.buildersList = new Map();
    this.buildingUpgradesList = new Map();
    this.researchUpgradesList = new Map();
    this.notificationsList = new Map();
    this.upgradeRecommendationsList = new Map();
    this.attackStrategiesList = new Map();
    
    this.userIdCounter = 1;
    this.resourceIdCounter = 1;
    this.villageInfoIdCounter = 1;
    this.builderIdCounter = 1;
    this.buildingUpgradeIdCounter = 1;
    this.researchUpgradeIdCounter = 1;
    this.notificationIdCounter = 1;
    this.upgradeRecommendationIdCounter = 1;
    this.attackStrategyIdCounter = 1;
    
    // Initialize with demo data for testing
    this.initializeDemoData();
  }

  private initializeDemoData() {
    // Create a demo user
    const demoUser: User = {
      id: this.userIdCounter++,
      username: "demo",
      password: "password"
    };
    this.users.set(demoUser.id, demoUser);
    
    // Create resources for demo user
    const demoResources: Resource = {
      id: this.resourceIdCounter++,
      userId: demoUser.id,
      gold: 1245890,
      goldCapacity: 2000000,
      goldRate: 2400,
      elixir: 876430,
      elixirCapacity: 2000000,
      elixirRate: 2200,
      darkElixir: 32450,
      darkElixirCapacity: 80000,
      darkElixirRate: 120,
      lastUpdated: new Date()
    };
    this.resources.set(demoResources.id, demoResources);
    
    // Create village info for demo user
    const demoVillageInfo: VillageInfo = {
      id: this.villageInfoIdCounter++,
      userId: demoUser.id,
      townHallLevel: 11,
      trophies: 2345,
      league: "Crystal II",
      shieldEndTime: new Date(Date.now() + 3 * 60 * 60 * 1000), // 3 hours from now
      builderBaseEnabled: true,
      clanWarStatus: "Preparation day"
    };
    this.villageInfos.set(demoVillageInfo.id, demoVillageInfo);
    
    // Create builders for demo user
    const demoBuilders: Builder = {
      id: this.builderIdCounter++,
      userId: demoUser.id,
      totalBuilders: 5,
      availableBuilders: 1
    };
    this.buildersList.set(demoBuilders.id, demoBuilders);
    
    // Create building upgrades for demo user
    const now = new Date();
    
    // X-Bow upgrade
    const xbowUpgrade: BuildingUpgrade = {
      id: this.buildingUpgradeIdCounter++,
      userId: demoUser.id,
      builderId: 2, // Assigned to builder 2
      buildingName: "X-Bow",
      currentLevel: 4,
      targetLevel: 5,
      startTime: new Date(now.getTime() - 24 * 60 * 60 * 1000), // Started 1 day ago
      endTime: new Date(now.getTime() + 62 * 60 * 60 * 1000), // Ends in 2.5 days
      resourceType: "gold",
      resourceCost: 7200000
    };
    this.buildingUpgradesList.set(xbowUpgrade.id, xbowUpgrade);
    
    // Cannon upgrade
    const cannonUpgrade: BuildingUpgrade = {
      id: this.buildingUpgradeIdCounter++,
      userId: demoUser.id,
      builderId: 3, // Assigned to builder 3
      buildingName: "Cannon",
      currentLevel: 11,
      targetLevel: 12,
      startTime: new Date(now.getTime() - 16 * 60 * 60 * 1000), // Started 16 hours ago
      endTime: new Date(now.getTime() + 8 * 60 * 60 * 1000), // Ends in 8 hours
      resourceType: "gold",
      resourceCost: 3500000
    };
    this.buildingUpgradesList.set(cannonUpgrade.id, cannonUpgrade);
    
    // Inferno Tower upgrade
    const infernoUpgrade: BuildingUpgrade = {
      id: this.buildingUpgradeIdCounter++,
      userId: demoUser.id,
      builderId: 4, // Assigned to builder 4
      buildingName: "Inferno Tower",
      currentLevel: 2,
      targetLevel: 3,
      startTime: new Date(now.getTime() - 20 * 60 * 60 * 1000), // Started 20 hours ago
      endTime: new Date(now.getTime() + 27 * 60 * 60 * 1000), // Ends in 27 hours
      resourceType: "gold",
      resourceCost: 5000000
    };
    this.buildingUpgradesList.set(infernoUpgrade.id, infernoUpgrade);
    
    // Barbarian King upgrade
    const bkUpgrade: BuildingUpgrade = {
      id: this.buildingUpgradeIdCounter++,
      userId: demoUser.id,
      builderId: 5, // Assigned to builder 5
      buildingName: "Barbarian King",
      currentLevel: 41,
      targetLevel: 42,
      startTime: new Date(now.getTime() - 24 * 60 * 60 * 1000), // Started 1 day ago
      endTime: new Date(now.getTime() + 94 * 60 * 60 * 1000), // Ends in 4 days
      resourceType: "darkElixir",
      resourceCost: 220000
    };
    this.buildingUpgradesList.set(bkUpgrade.id, bkUpgrade);
    
    // Research upgrade
    const valkyrieResearch: ResearchUpgrade = {
      id: this.researchUpgradeIdCounter++,
      userId: demoUser.id,
      troopName: "Valkyrie",
      currentLevel: 5,
      targetLevel: 6,
      startTime: new Date(now.getTime() - 16 * 60 * 60 * 1000), // Started 16 hours ago
      endTime: new Date(now.getTime() + 32 * 60 * 60 * 1000), // Ends in 32 hours (1d 8h)
      resourceType: "elixir",
      resourceCost: 6500000
    };
    this.researchUpgradesList.set(valkyrieResearch.id, valkyrieResearch);
    
    // Notifications
    const troopsReadyNotif: Notification = {
      id: this.notificationIdCounter++,
      userId: demoUser.id,
      title: "Troops Ready",
      message: "Your army training has completed and is ready for battle.",
      type: "troops",
      isRead: false,
      createdAt: new Date(now.getTime() - 5 * 60 * 1000) // 5 minutes ago
    };
    this.notificationsList.set(troopsReadyNotif.id, troopsReadyNotif);
    
    const builderAvailableNotif: Notification = {
      id: this.notificationIdCounter++,
      userId: demoUser.id,
      title: "Builder Available",
      message: "One builder has completed upgrades and is now available.",
      type: "builder",
      isRead: false,
      createdAt: new Date(now.getTime() - 12 * 60 * 1000) // 12 minutes ago
    };
    this.notificationsList.set(builderAvailableNotif.id, builderAvailableNotif);
    
    const goldStorageNotif: Notification = {
      id: this.notificationIdCounter++,
      userId: demoUser.id,
      title: "Gold Storage Near Capacity",
      message: "Your gold storage is at 90% capacity. Consider spending resources.",
      type: "resource",
      isRead: false,
      createdAt: new Date(now.getTime() - 35 * 60 * 1000) // 35 minutes ago
    };
    this.notificationsList.set(goldStorageNotif.id, goldStorageNotif);
    
    const clanWarNotif: Notification = {
      id: this.notificationIdCounter++,
      userId: demoUser.id,
      title: "Clan War Preparation",
      message: "War preparation ends in 5 hours. Don't forget to donate troops.",
      type: "war",
      isRead: false,
      createdAt: new Date(now.getTime() - 60 * 60 * 1000) // 1 hour ago
    };
    this.notificationsList.set(clanWarNotif.id, clanWarNotif);
    
    // Upgrade recommendations
    const airDefenseRecommendation: UpgradeRecommendation = {
      id: this.upgradeRecommendationIdCounter++,
      userId: demoUser.id,
      buildingName: "Air Defense",
      currentLevel: 7,
      targetLevel: 8,
      resourceType: "gold",
      resourceCost: 7200000,
      priority: "high",
      reason: "Upgrading air defenses will improve your base's anti-air capabilities by 24%."
    };
    this.upgradeRecommendationsList.set(airDefenseRecommendation.id, airDefenseRecommendation);
    
    const wizardTowerRecommendation: UpgradeRecommendation = {
      id: this.upgradeRecommendationIdCounter++,
      userId: demoUser.id,
      buildingName: "Wizard Tower",
      currentLevel: 8,
      targetLevel: 9,
      resourceType: "elixir",
      resourceCost: 6500000,
      priority: "medium",
      reason: "Will improve splash damage against ground and air troops by 18%."
    };
    this.upgradeRecommendationsList.set(wizardTowerRecommendation.id, wizardTowerRecommendation);
    
    const balloonRecommendation: UpgradeRecommendation = {
      id: this.upgradeRecommendationIdCounter++,
      userId: demoUser.id,
      buildingName: "Balloon",
      currentLevel: 7,
      targetLevel: 8,
      resourceType: "elixir",
      resourceCost: 8500000,
      priority: "high",
      reason: "Your attack strategy relies heavily on balloons. This upgrade increases damage by 20%."
    };
    this.upgradeRecommendationsList.set(balloonRecommendation.id, balloonRecommendation);
    
    const goldMineRecommendation: UpgradeRecommendation = {
      id: this.upgradeRecommendationIdCounter++,
      userId: demoUser.id,
      buildingName: "Gold Mine",
      currentLevel: 12,
      targetLevel: 13,
      resourceType: "elixir",
      resourceCost: 3200000,
      priority: "low",
      reason: "Increases gold production by 300 per hour. Helps maintain gold income for future upgrades."
    };
    this.upgradeRecommendationsList.set(goldMineRecommendation.id, goldMineRecommendation);
    
    // Attack strategy
    const laloonStrategy: AttackStrategy = {
      id: this.attackStrategyIdCounter++,
      userId: demoUser.id,
      name: "LaLoon Attack",
      description: "This base has exposed air defenses that make it vulnerable to a LaLoon attack strategy. Approach from the northeast with lava hounds tanking damage while balloons target defenses.",
      armyComposition: [
        { name: "Lava Hound", count: 3, housing: 30 },
        { name: "Balloon", count: 26, housing: 5 },
        { name: "Minion", count: 20, housing: 2 }
      ],
      spells: [
        { name: "Rage", count: 3 },
        { name: "Haste", count: 2 }
      ],
      steps: [
        "Deploy Lava Hounds to target Air Defenses from the northeast side.",
        "Send Balloons in a line behind Lava Hounds, focusing on defensive structures.",
        "Use Rage spells over high-value targets including Inferno Towers and X-Bows.",
        "Deploy Haste spells to speed up Balloons approach to defenses.",
        "Once defenses are down, send in Minions for cleanup of remaining buildings."
      ],
      recommendedAgainst: "Town Hall 10-11 bases with exposed air defenses"
    };
    this.attackStrategiesList.set(laloonStrategy.id, laloonStrategy);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Resource methods
  async getResources(userId: number): Promise<Resource | undefined> {
    return Array.from(this.resources.values()).find(r => r.userId === userId);
  }
  
  async updateResources(userId: number, resourceData: Partial<Resource>): Promise<Resource> {
    const resource = await this.getResources(userId);
    if (!resource) {
      throw new Error(`Resources not found for user ${userId}`);
    }
    
    const updatedResource: Resource = { ...resource, ...resourceData, lastUpdated: new Date() };
    this.resources.set(resource.id, updatedResource);
    return updatedResource;
  }
  
  async createResources(insertResource: InsertResource): Promise<Resource> {
    const id = this.resourceIdCounter++;
    const resource: Resource = { ...insertResource, id, lastUpdated: new Date() };
    this.resources.set(id, resource);
    return resource;
  }
  
  // Village info methods
  async getVillageInfo(userId: number): Promise<VillageInfo | undefined> {
    return Array.from(this.villageInfos.values()).find(v => v.userId === userId);
  }
  
  async updateVillageInfo(userId: number, infoData: Partial<VillageInfo>): Promise<VillageInfo> {
    const info = await this.getVillageInfo(userId);
    if (!info) {
      throw new Error(`Village info not found for user ${userId}`);
    }
    
    const updatedInfo: VillageInfo = { ...info, ...infoData };
    this.villageInfos.set(info.id, updatedInfo);
    return updatedInfo;
  }
  
  async createVillageInfo(insertInfo: InsertVillageInfo): Promise<VillageInfo> {
    const id = this.villageInfoIdCounter++;
    const info: VillageInfo = { ...insertInfo, id };
    this.villageInfos.set(id, info);
    return info;
  }
  
  // Builder methods
  async getBuilders(userId: number): Promise<Builder | undefined> {
    return Array.from(this.buildersList.values()).find(b => b.userId === userId);
  }
  
  async updateBuilders(userId: number, builderData: Partial<Builder>): Promise<Builder> {
    const builder = await this.getBuilders(userId);
    if (!builder) {
      throw new Error(`Builders not found for user ${userId}`);
    }
    
    const updatedBuilder: Builder = { ...builder, ...builderData };
    this.buildersList.set(builder.id, updatedBuilder);
    return updatedBuilder;
  }
  
  async createBuilders(insertBuilder: InsertBuilder): Promise<Builder> {
    const id = this.builderIdCounter++;
    const builder: Builder = { ...insertBuilder, id };
    this.buildersList.set(id, builder);
    return builder;
  }
  
  // Building upgrade methods
  async getBuildingUpgrades(userId: number): Promise<BuildingUpgrade[]> {
    return Array.from(this.buildingUpgradesList.values()).filter(u => u.userId === userId);
  }
  
  async getBuildingUpgrade(id: number): Promise<BuildingUpgrade | undefined> {
    return this.buildingUpgradesList.get(id);
  }
  
  async createBuildingUpgrade(insertUpgrade: InsertBuildingUpgrade): Promise<BuildingUpgrade> {
    const id = this.buildingUpgradeIdCounter++;
    const upgrade: BuildingUpgrade = { 
      ...insertUpgrade, 
      id,
      startTime: new Date()
    };
    this.buildingUpgradesList.set(id, upgrade);
    return upgrade;
  }
  
  async updateBuildingUpgrade(id: number, upgradeData: Partial<BuildingUpgrade>): Promise<BuildingUpgrade> {
    const upgrade = await this.getBuildingUpgrade(id);
    if (!upgrade) {
      throw new Error(`Building upgrade not found with id ${id}`);
    }
    
    const updatedUpgrade: BuildingUpgrade = { ...upgrade, ...upgradeData };
    this.buildingUpgradesList.set(id, updatedUpgrade);
    return updatedUpgrade;
  }
  
  async deleteBuildingUpgrade(id: number): Promise<void> {
    this.buildingUpgradesList.delete(id);
  }
  
  // Research upgrade methods
  async getResearchUpgrades(userId: number): Promise<ResearchUpgrade[]> {
    return Array.from(this.researchUpgradesList.values()).filter(u => u.userId === userId);
  }
  
  async getResearchUpgrade(id: number): Promise<ResearchUpgrade | undefined> {
    return this.researchUpgradesList.get(id);
  }
  
  async createResearchUpgrade(insertUpgrade: InsertResearchUpgrade): Promise<ResearchUpgrade> {
    const id = this.researchUpgradeIdCounter++;
    const upgrade: ResearchUpgrade = { 
      ...insertUpgrade, 
      id,
      startTime: new Date()
    };
    this.researchUpgradesList.set(id, upgrade);
    return upgrade;
  }
  
  async updateResearchUpgrade(id: number, upgradeData: Partial<ResearchUpgrade>): Promise<ResearchUpgrade> {
    const upgrade = await this.getResearchUpgrade(id);
    if (!upgrade) {
      throw new Error(`Research upgrade not found with id ${id}`);
    }
    
    const updatedUpgrade: ResearchUpgrade = { ...upgrade, ...upgradeData };
    this.researchUpgradesList.set(id, updatedUpgrade);
    return updatedUpgrade;
  }
  
  async deleteResearchUpgrade(id: number): Promise<void> {
    this.researchUpgradesList.delete(id);
  }
  
  // Notification methods
  async getNotifications(userId: number): Promise<Notification[]> {
    return Array.from(this.notificationsList.values())
      .filter(n => n.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.notificationIdCounter++;
    const notification: Notification = { 
      ...insertNotification, 
      id,
      isRead: false,
      createdAt: new Date()
    };
    this.notificationsList.set(id, notification);
    return notification;
  }
  
  async markNotificationAsRead(id: number): Promise<Notification> {
    const notification = this.notificationsList.get(id);
    if (!notification) {
      throw new Error(`Notification not found with id ${id}`);
    }
    
    const updatedNotification: Notification = { ...notification, isRead: true };
    this.notificationsList.set(id, updatedNotification);
    return updatedNotification;
  }
  
  async deleteNotification(id: number): Promise<void> {
    this.notificationsList.delete(id);
  }
  
  // Upgrade recommendation methods
  async getUpgradeRecommendations(userId: number): Promise<UpgradeRecommendation[]> {
    return Array.from(this.upgradeRecommendationsList.values()).filter(r => r.userId === userId);
  }
  
  async createUpgradeRecommendation(insertRecommendation: InsertUpgradeRecommendation): Promise<UpgradeRecommendation> {
    const id = this.upgradeRecommendationIdCounter++;
    const recommendation: UpgradeRecommendation = { ...insertRecommendation, id };
    this.upgradeRecommendationsList.set(id, recommendation);
    return recommendation;
  }
  
  async deleteUpgradeRecommendation(id: number): Promise<void> {
    this.upgradeRecommendationsList.delete(id);
  }
  
  // Attack strategy methods
  async getAttackStrategies(userId: number): Promise<AttackStrategy[]> {
    return Array.from(this.attackStrategiesList.values()).filter(s => s.userId === userId);
  }
  
  async getAttackStrategy(id: number): Promise<AttackStrategy | undefined> {
    return this.attackStrategiesList.get(id);
  }
  
  async createAttackStrategy(insertStrategy: InsertAttackStrategy): Promise<AttackStrategy> {
    const id = this.attackStrategyIdCounter++;
    const strategy: AttackStrategy = { ...insertStrategy, id };
    this.attackStrategiesList.set(id, strategy);
    return strategy;
  }
  
  async updateAttackStrategy(id: number, strategyData: Partial<AttackStrategy>): Promise<AttackStrategy> {
    const strategy = await this.getAttackStrategy(id);
    if (!strategy) {
      throw new Error(`Attack strategy not found with id ${id}`);
    }
    
    const updatedStrategy: AttackStrategy = { ...strategy, ...strategyData };
    this.attackStrategiesList.set(id, updatedStrategy);
    return updatedStrategy;
  }
  
  async deleteAttackStrategy(id: number): Promise<void> {
    this.attackStrategiesList.delete(id);
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async getResources(userId: number): Promise<Resource | undefined> {
    const [resource] = await db.select().from(resources).where(eq(resources.userId, userId));
    return resource || undefined;
  }
  
  async updateResources(userId: number, resourceData: Partial<Resource>): Promise<Resource> {
    const resource = await this.getResources(userId);
    if (!resource) {
      throw new Error(`Resources not found for user ${userId}`);
    }
    
    const [updatedResource] = await db
      .update(resources)
      .set({ ...resourceData, lastUpdated: new Date() })
      .where(eq(resources.id, resource.id))
      .returning();
      
    return updatedResource;
  }
  
  async createResources(insertResource: InsertResource): Promise<Resource> {
    // Make sure all required fields are present
    const resourceToInsert: InsertResource = {
      userId: insertResource.userId,
      gold: insertResource.gold || 0,
      goldCapacity: insertResource.goldCapacity || 0,
      goldRate: insertResource.goldRate || 0,
      elixir: insertResource.elixir || 0, 
      elixirCapacity: insertResource.elixirCapacity || 0,
      elixirRate: insertResource.elixirRate || 0,
      darkElixir: insertResource.darkElixir || 0,
      darkElixirCapacity: insertResource.darkElixirCapacity || 0,
      darkElixirRate: insertResource.darkElixirRate || 0
    };
      
    const [resource] = await db
      .insert(resources)
      .values(resourceToInsert)
      .returning();
      
    return resource;
  }
  
  async getVillageInfo(userId: number): Promise<VillageInfo | undefined> {
    const [info] = await db.select().from(villageInfo).where(eq(villageInfo.userId, userId));
    return info || undefined;
  }
  
  async updateVillageInfo(userId: number, infoData: Partial<VillageInfo>): Promise<VillageInfo> {
    const info = await this.getVillageInfo(userId);
    if (!info) {
      throw new Error(`Village info not found for user ${userId}`);
    }
    
    const [updatedInfo] = await db
      .update(villageInfo)
      .set(infoData)
      .where(eq(villageInfo.id, info.id))
      .returning();
      
    return updatedInfo;
  }
  
  async createVillageInfo(insertInfo: InsertVillageInfo): Promise<VillageInfo> {
    // Make sure all required fields are present
    const infoToInsert: InsertVillageInfo = {
      userId: insertInfo.userId,
      townHallLevel: insertInfo.townHallLevel || 1,
      trophies: insertInfo.trophies || 0,
      league: insertInfo.league || null,
      shieldEndTime: insertInfo.shieldEndTime || null,
      builderBaseEnabled: insertInfo.builderBaseEnabled || null,
      clanWarStatus: insertInfo.clanWarStatus || null
    };
    
    const [info] = await db
      .insert(villageInfo)
      .values(infoToInsert)
      .returning();
      
    return info;
  }
  
  async getBuilders(userId: number): Promise<Builder | undefined> {
    const [builder] = await db.select().from(builders).where(eq(builders.userId, userId));
    return builder || undefined;
  }
  
  async updateBuilders(userId: number, builderData: Partial<Builder>): Promise<Builder> {
    const builder = await this.getBuilders(userId);
    if (!builder) {
      throw new Error(`Builders not found for user ${userId}`);
    }
    
    const [updatedBuilder] = await db
      .update(builders)
      .set(builderData)
      .where(eq(builders.id, builder.id))
      .returning();
      
    return updatedBuilder;
  }
  
  async createBuilders(insertBuilder: InsertBuilder): Promise<Builder> {
    // Make sure all required fields are present
    const builderToInsert: InsertBuilder = {
      userId: insertBuilder.userId,
      totalBuilders: insertBuilder.totalBuilders || 0,
      availableBuilders: insertBuilder.availableBuilders || 0
    };
    
    const [builder] = await db
      .insert(builders)
      .values(builderToInsert)
      .returning();
      
    return builder;
  }
  
  async getBuildingUpgrades(userId: number): Promise<BuildingUpgrade[]> {
    const upgrades = await db.select().from(buildingUpgrades).where(eq(buildingUpgrades.userId, userId));
    return upgrades;
  }
  
  async getBuildingUpgrade(id: number): Promise<BuildingUpgrade | undefined> {
    const [upgrade] = await db.select().from(buildingUpgrades).where(eq(buildingUpgrades.id, id));
    return upgrade || undefined;
  }
  
  async createBuildingUpgrade(insertUpgrade: InsertBuildingUpgrade): Promise<BuildingUpgrade> {
    const [upgrade] = await db
      .insert(buildingUpgrades)
      .values(insertUpgrade)
      .returning();
      
    return upgrade;
  }
  
  async updateBuildingUpgrade(id: number, upgradeData: Partial<BuildingUpgrade>): Promise<BuildingUpgrade> {
    const [updatedUpgrade] = await db
      .update(buildingUpgrades)
      .set(upgradeData)
      .where(eq(buildingUpgrades.id, id))
      .returning();
      
    return updatedUpgrade;
  }
  
  async deleteBuildingUpgrade(id: number): Promise<void> {
    await db.delete(buildingUpgrades).where(eq(buildingUpgrades.id, id));
  }
  
  async getResearchUpgrades(userId: number): Promise<ResearchUpgrade[]> {
    const upgrades = await db.select().from(researchUpgrades).where(eq(researchUpgrades.userId, userId));
    return upgrades;
  }
  
  async getResearchUpgrade(id: number): Promise<ResearchUpgrade | undefined> {
    const [upgrade] = await db.select().from(researchUpgrades).where(eq(researchUpgrades.id, id));
    return upgrade || undefined;
  }
  
  async createResearchUpgrade(insertUpgrade: InsertResearchUpgrade): Promise<ResearchUpgrade> {
    const [upgrade] = await db
      .insert(researchUpgrades)
      .values(insertUpgrade)
      .returning();
      
    return upgrade;
  }
  
  async updateResearchUpgrade(id: number, upgradeData: Partial<ResearchUpgrade>): Promise<ResearchUpgrade> {
    const [updatedUpgrade] = await db
      .update(researchUpgrades)
      .set(upgradeData)
      .where(eq(researchUpgrades.id, id))
      .returning();
      
    return updatedUpgrade;
  }
  
  async deleteResearchUpgrade(id: number): Promise<void> {
    await db.delete(researchUpgrades).where(eq(researchUpgrades.id, id));
  }
  
  async getNotifications(userId: number): Promise<Notification[]> {
    const notifs = await db.select().from(notifications).where(eq(notifications.userId, userId));
    return notifs;
  }
  
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const [notification] = await db
      .insert(notifications)
      .values(insertNotification)
      .returning();
      
    return notification;
  }
  
  async markNotificationAsRead(id: number): Promise<Notification> {
    const [updatedNotification] = await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id))
      .returning();
      
    return updatedNotification;
  }
  
  async deleteNotification(id: number): Promise<void> {
    await db.delete(notifications).where(eq(notifications.id, id));
  }
  
  async getUpgradeRecommendations(userId: number): Promise<UpgradeRecommendation[]> {
    const recommendations = await db.select().from(upgradeRecommendations).where(eq(upgradeRecommendations.userId, userId));
    return recommendations;
  }
  
  async createUpgradeRecommendation(insertRecommendation: InsertUpgradeRecommendation): Promise<UpgradeRecommendation> {
    const [recommendation] = await db
      .insert(upgradeRecommendations)
      .values(insertRecommendation)
      .returning();
      
    return recommendation;
  }
  
  async deleteUpgradeRecommendation(id: number): Promise<void> {
    await db.delete(upgradeRecommendations).where(eq(upgradeRecommendations.id, id));
  }
  
  async getAttackStrategies(userId: number): Promise<AttackStrategy[]> {
    const strategies = await db.select().from(attackStrategies).where(eq(attackStrategies.userId, userId));
    return strategies;
  }
  
  async getAttackStrategy(id: number): Promise<AttackStrategy | undefined> {
    const [strategy] = await db.select().from(attackStrategies).where(eq(attackStrategies.id, id));
    return strategy || undefined;
  }
  
  async createAttackStrategy(insertStrategy: InsertAttackStrategy): Promise<AttackStrategy> {
    const [strategy] = await db
      .insert(attackStrategies)
      .values(insertStrategy)
      .returning();
      
    return strategy;
  }
  
  async updateAttackStrategy(id: number, strategyData: Partial<AttackStrategy>): Promise<AttackStrategy> {
    const [updatedStrategy] = await db
      .update(attackStrategies)
      .set(strategyData)
      .where(eq(attackStrategies.id, id))
      .returning();
      
    return updatedStrategy;
  }
  
  async deleteAttackStrategy(id: number): Promise<void> {
    await db.delete(attackStrategies).where(eq(attackStrategies.id, id));
  }
}

// Initialize storage with database implementation
export const storage = new DatabaseStorage();
